import 'package:equatable/equatable.dart';
import 'package:json_annotation/json_annotation.dart';

import 'episode.dart';
import 'media_extras.dart';
import 'provider_info.dart';

part 'media_detail.g.dart';

enum MediaStatus {
  @JsonValue('ongoing')
  ongoing,
  @JsonValue('completed')
  completed,
  @JsonValue('hiatus')
  hiatus,
  @JsonValue('cancelled')
  cancelled,
  @JsonValue('unknown')
  unknown,
}

/// Full series detail. The video-native analogue of Sozo Read's
/// `BookDetail` (chapters → episodes, authors → studios).
@JsonSerializable(explicitToJson: true)
class MediaDetail extends Equatable {
  final String id;
  final String title;
  final String? englishTitle;
  final String? cover;
  final Map<String, String>? coverHeaders;
  final String url;
  final String? description;

  @JsonKey(
    unknownEnumValue: MediaStatus.unknown,
    defaultValue: MediaStatus.unknown,
  )
  final MediaStatus status;

  @JsonKey(defaultValue: <String>[])
  final List<String> genres;

  @JsonKey(defaultValue: <String>[])
  final List<String> studios;

  @JsonKey(defaultValue: <Episode>[])
  final List<Episode> episodes;

  /// Cast members (actors / voice actors). Populated by sources that expose
  /// it (e.g. NetMirror's `post.php` cast field); empty for sources that
  /// don't (e.g. AllAnime). Drives the Cast tab.
  @JsonKey(defaultValue: <String>[])
  final List<String> cast;

  /// Release year, when the source provides it. Null otherwise — the meta
  /// line omits the segment rather than inventing a value.
  final String? year;

  final ProviderType type;
  final String sourceId;
  final int? subCount;
  final int? dubCount;

  /// MyAnimeList id, when the source exposes it (anime). Drives tracker sync
  /// (AniList/MAL/Simkl) — the scrobble target and the list-import match key.
  final int? malId;

  /// TMDB id (movies/series), when the source exposes it. Drives Simkl tracking
  /// for non-anime content; [tmdbIsTv] selects TMDB's movie vs tv namespace.
  final int? tmdbId;
  final bool tmdbIsTv;

  /// Whether this is an episodic video title (series/anime series).
  /// Runtime/persistence-safe classification supplied by the source bridge.
  /// This must not be inferred from [episodes], because movies use a synthetic
  /// single episode internally for the unified playback/download pipeline.
  @JsonKey(defaultValue: false)
  final bool isSeries;

  /// IMDb id (e.g. `tt1234567`), when the source exposes it but not a TMDB id.
  /// Also drives Simkl tracking — Simkl accepts an `imdb` id in its ids object.
  final String? imdbId;

  /// Rich cast (name + role + photo) supplied directly by the source, when it
  /// has one (e.g. CloudStream's `actors`). Runtime-only — never persisted.
  /// When present it feeds the Cast tab directly, skipping id-based enrichment.
  @JsonKey(includeFromJson: false, includeToJson: false)
  final List<CastMember> castMembers;

  /// Related/recommended titles supplied directly by the source (e.g.
  /// CloudStream's `recommendations`). Runtime-only — never persisted. When
  /// present it feeds the Relations tab directly, skipping id-based enrichment.
  @JsonKey(includeFromJson: false, includeToJson: false)
  final List<MediaRelation> relations;

  /// Full release date (e.g. "2026-09-25"), when provided by TMDB/metadata.
  /// Runtime-only — not serialized to JSON.
  @JsonKey(includeFromJson: false, includeToJson: false)
  final String? releaseDate;

  /// Official TMDB status (e.g. "Released", "Post Production", "Planned").
  /// Runtime-only — not serialized to JSON.
  @JsonKey(includeFromJson: false, includeToJson: false)
  final String? tmdbStatus;

  /// Known season numbers (e.g. [1, 2, 3, 4]) reported by metadata (e.g. TMDB).
  /// Runtime-only — not serialized to JSON.
  @JsonKey(includeFromJson: false, includeToJson: false)
  final List<int> availableSeasons;

  const MediaDetail({
    required this.id,
    required this.title,
    this.englishTitle,
    this.cover,
    this.coverHeaders,
    required this.url,
    this.description,
    this.status = MediaStatus.unknown,
    this.genres = const [],
    this.studios = const [],
    this.episodes = const [],
    this.cast = const [],
    this.year,
    required this.type,
    required this.sourceId,
    this.subCount,
    this.dubCount,
    this.malId,
    this.tmdbId,
    this.tmdbIsTv = false,
    this.isSeries = false,
    this.imdbId,
    this.castMembers = const [],
    this.relations = const [],
    this.releaseDate,
    this.tmdbStatus,
    this.availableSeasons = const [],
  });

  factory MediaDetail.fromJson(Map<String, dynamic> json) =>
      _$MediaDetailFromJson(json);
  Map<String, dynamic> toJson() => _$MediaDetailToJson(this);

  MediaDetail copyWith({
    String? id,
    String? title,
    String? englishTitle,
    String? cover,
    Map<String, String>? coverHeaders,
    String? url,
    String? description,
    MediaStatus? status,
    List<String>? genres,
    List<String>? studios,
    List<Episode>? episodes,
    List<String>? cast,
    String? year,
    ProviderType? type,
    String? sourceId,
    int? subCount,
    int? dubCount,
    int? malId,
    int? tmdbId,
    bool? tmdbIsTv,
    bool? isSeries,
    String? imdbId,
    List<CastMember>? castMembers,
    List<MediaRelation>? relations,
    String? releaseDate,
    String? tmdbStatus,
    List<int>? availableSeasons,
  }) => MediaDetail(
    id: id ?? this.id,
    title: title ?? this.title,
    englishTitle: englishTitle ?? this.englishTitle,
    cover: cover ?? this.cover,
    coverHeaders: coverHeaders ?? this.coverHeaders,
    url: url ?? this.url,
    description: description ?? this.description,
    status: status ?? this.status,
    genres: genres ?? this.genres,
    studios: studios ?? this.studios,
    episodes: episodes ?? this.episodes,
    cast: cast ?? this.cast,
    year: year ?? this.year,
    type: type ?? this.type,
    sourceId: sourceId ?? this.sourceId,
    subCount: subCount ?? this.subCount,
    dubCount: dubCount ?? this.dubCount,
    malId: malId ?? this.malId,
    tmdbId: tmdbId ?? this.tmdbId,
    tmdbIsTv: tmdbIsTv ?? this.tmdbIsTv,
    isSeries: isSeries ?? this.isSeries,
    imdbId: imdbId ?? this.imdbId,
    castMembers: castMembers ?? this.castMembers,
    relations: relations ?? this.relations,
    releaseDate: releaseDate ?? this.releaseDate,
    tmdbStatus: tmdbStatus ?? this.tmdbStatus,
    availableSeasons: availableSeasons ?? this.availableSeasons,
  );

  @override
  List<Object?> get props => [
    id,
    title,
    englishTitle,
    cover,
    coverHeaders,
    url,
    description,
    status,
    genres,
    studios,
    episodes,
    cast,
    year,
    type,
    sourceId,
    subCount,
    dubCount,
    malId,
    tmdbId,
    tmdbIsTv,
    isSeries,
    imdbId,
    castMembers,
    relations,
    releaseDate,
    tmdbStatus,
    availableSeasons,
  ];
}
