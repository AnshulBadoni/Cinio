
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'image_fade.dart';
import 'package:palette_generator/palette_generator.dart';

import '../di/injector.dart';
import 'native_cover_provider.dart';
import 'poster_card.dart';
import 'cinio_title_style.dart';
import '../metadata/title_logo_service.dart';
import '../models/media_item.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';

/// Lightweight metadata shown under the hero title: a few genres + episode
/// count (or year for movies). Lazily fetched, so it never blocks the banner.
class HeroMeta {
  const HeroMeta({
    this.genres = const [],
    this.episodeCount = 0,
    this.year,
    this.rating,
  });
  final List<String> genres;
  final int episodeCount;
  final String? year;
  final double? rating;
}

/// Apple-TV+-style cinematic hero: a rounded inset artwork card floating on the
/// page, with a colour-matched top gradient pulled from the cover's dominant
/// colour, a centred title, an uppercase genres·episodes line, and a clean
/// white Play + glass My-List / Info.
class FeaturedHero extends StatefulWidget {
  const FeaturedHero({
    super.key,
    required this.item,
    required this.inList,
    required this.onPlay,
    required this.onInfo,
    required this.onToggleList,
    this.heroTag,
    this.metaFuture,
    this.parallax = 0,
    this.kenBurns = false,
    this.wrapButton,
    this.reading = false,
    this.fullBleed = false,
    this.stretch,
  });

  final MediaItem item;
  final bool inList;
  final String? heroTag;

  /// Manga/novel mode: the primary action reads "Read" with a book glyph
  /// instead of "Play" with a triangle. Defaults to false, so every existing
  /// caller — including both TV heroes, which have no content mode — renders
  /// exactly as before.
  final bool reading;

  /// Removes the inset card treatment and lets the artwork reach the screen
  /// edges. Used by the Home hero; other FeaturedHero callers stay unchanged.
  final bool fullBleed;
  final ValueListenable<double>? stretch;

  final VoidCallback onPlay;
  final VoidCallback onInfo;
  final VoidCallback onToggleList;

  /// Lazily-fetched genres + episode count for this title.
  final Future<HeroMeta?>? metaFuture;

  /// Page-relative offset (-1..1) used to parallax the blurred bleed in the
  /// parallax-slide carousel mode. 0 = no parallax.
  final double parallax;

  /// Slowly zoom the card artwork (Ken-Burns) — used in the cinematic mode.
  final bool kenBurns;

  /// Optional button decorator for TV D-pad focus.  When supplied, each hero
  /// action button (Play, My List, Info) is passed through this builder so TV
  /// callers can inject [TvFocusable] focus around the buttons without altering
  /// phone behaviour in any way.
  ///
  /// [autofocus] is true only for the primary Play button.
  ///
  /// Defaults to null — the phone render is byte-identical when null.
  final Widget Function(Widget child, VoidCallback onTap, {bool autofocus})?
      wrapButton;

  @override
  State<FeaturedHero> createState() => _FeaturedHeroState();
}

class _FeaturedHeroState extends State<FeaturedHero> {
  static final ValueNotifier<double> _zeroStretch = ValueNotifier<double>(0);
  // Cache extracted colours so swiping back doesn't recompute the palette.
  static final Map<String, Color> _paletteCache = {};
  Color? _artColor;
  String? _logoUrl;

  @override
  void initState() {
    super.initState();
    _loadPalette();
    _loadLogo();
  }

  @override
  void didUpdateWidget(FeaturedHero old) {
    super.didUpdateWidget(old);
    if (old.item.cover != widget.item.cover || old.item.heroImage != widget.item.heroImage) {
      _artColor = null;
      _logoUrl = null;
      _loadPalette();
      _loadLogo();
      }
  }

  /// Resolve the title logo independently of the hero artwork. The artwork
  /// itself stays on the catalog poster for the whole lifetime of the hero,
  /// avoiding a visible poster-to-poster swap while metadata loads.
  Future<void> _loadLogo() async {
    if (!sl.isRegistered<TitleLogoService>()) return;
    try {
      final url = await sl<TitleLogoService>().logoFor(widget.item);
      if (mounted && url != null && url.isNotEmpty) {
        setState(() => _logoUrl = url);
      }
    } catch (_) {}
  }

  Future<void> _loadPalette() async {
    final cover = widget.item.heroImage ?? widget.item.cover;
    if (cover == null || cover.isEmpty) return;
    final cached = _paletteCache[cover];
    if (cached != null) {
      setState(() => _artColor = cached);
      return;
    }
    try {
      final pal = await PaletteGenerator.fromImageProvider(
        // Decode a SMALL copy for the palette: the dominant colour is identical,
        // but this avoids a full-resolution decode on the UI isolate every time
        // the cinematic carousel rotates to a new cover (the 30s-of-lag cause).
        ResizeImage(
          nativeCoverProvider(cover, widget.item.coverHeaders),
          width: 180,
        ),
        size: const Size(180, 270),
        maximumColorCount: 8,
      );
      final c =
          pal.vibrantColor?.color ??
          pal.dominantColor?.color ??
          pal.darkVibrantColor?.color ??
          pal.mutedColor?.color;
      if (c != null) {
        _paletteCache[cover] = c;
        if (mounted) setState(() => _artColor = c);
      }
    } catch (_) {
      /* keep fallback */
    }
  }


  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    final cover = item.heroImage ?? item.cover;
    final hasCover = cover != null && cover.isNotEmpty;
    final tint = _artColor ?? AppColors.surface2;

    final provider = hasCover
        ? nativeCoverProvider(cover, item.coverHeaders)
        : null;

    return RepaintBoundary(
      child: Stack(
        fit: StackFit.expand,
        children: [
          // Plain page background.
          ColoredBox(color: AppColors.bg),

          // Soft ambient glow of the art's own colour bleeding OUTSIDE the card.
          // RADIAL so it fades to the page colour on every side — it dies out
          // before reaching the banner's bottom, so there's no straight cut-off
          // line like the old full-width "box" bleed had.
          Positioned.fill(
            child: IgnorePointer(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: const Alignment(0, -0.15),
                    radius: 1.05,
                    colors: [
                      tint.withValues(alpha: 0.66),
                      tint.withValues(alpha: 0.28),
                      AppColors.bg.withValues(alpha: 0.0),
                    ],
                    stops: const [0.0, 0.5, 0.84],
                  ),
                ),
              ),
            ),
          ),

          // ── The artwork card, floating on the glow ────────────────────────
          // Rounded, no border/shadow; its bottom melts into the page colour so
          // there's no hard edge below it.
          if (widget.fullBleed)
            _card(provider, tint)
          else
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 90, 16, 40),
              child: _card(provider, tint),
            ),
        ],
      ),
    );
  }

  Widget _card(ImageProvider? provider, Color tint) {
    return ClipRRect(
      borderRadius: widget.fullBleed ? BorderRadius.zero : BorderRadius.circular(28),
      child: LayoutBuilder(
        builder: (context, constraints) {
          return Stack(
            fit: StackFit.expand,
            children: [
              ColoredBox(color: AppColors.bg),
              if (provider != null)
                Positioned.fill(
                  child: ValueListenableBuilder<double>(
                    valueListenable: widget.stretch ?? _zeroStretch,
                    builder: (context, overscroll, child) {
                      final scale = 1.0 + (overscroll / 420).clamp(0.0, 0.34);
                      return ClipRect(child: Transform.scale(alignment: Alignment.topCenter, scale: scale, child: child));
                    },
                    child: (widget.heroTag != null && widget.heroTag!.isNotEmpty)
                        ? Hero(
                            tag: widget.heroTag!,
                            createRectTween: (begin, end) =>
                                MaterialRectArcTween(begin: begin, end: end),
                            flightShuttleBuilder: posterHeroFlightShuttle,
                            child: Image(
                              image: provider,
                              fit: BoxFit.cover,
                              alignment: const Alignment(0, -0.20),
                              filterQuality: FilterQuality.high,
                              frameBuilder: imageFadeIn,
                              gaplessPlayback: true,
                            ),
                          )
                        : Image(
                            image: provider,
                            fit: BoxFit.cover,
                            alignment: const Alignment(0, -0.20),
                            filterQuality: FilterQuality.high,
                            frameBuilder: imageFadeIn,
                            gaplessPlayback: true,
                          ),
                  ),
                ),

              Positioned.fill(
                child: IgnorePointer(
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          tint.withValues(alpha: 0.72),
                          tint.withValues(alpha: 0.34),
                          tint.withValues(alpha: 0.08),
                          Colors.transparent,
                        ],
                        stops: const [0.0, 0.16, 0.34, 0.52],
                      ),
                    ),
                  ),
                ),
              ),
              Positioned.fill(
                child: IgnorePointer(
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          AppColors.bg.withValues(alpha: 0.0),
                          AppColors.bg.withValues(alpha: 0.68),
                          AppColors.bg,
                        ],
                        stops: const [0.44, 0.72, 1.0],
                      ),
                    ),
                  ),
                ),
              ),

              // Hero content stays anchored over the lower fade.
              Positioned(
                left: 20,
                right: 20,
                bottom: 40,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    GestureDetector(
                      behavior: HitTestBehavior.translucent,
                      onTap: widget.onInfo,
                      child: SizedBox(
                        height: 78,
                        width: double.infinity,
                        child: AnimatedSwitcher(
                          duration: const Duration(milliseconds: 180),
                          switchInCurve: Curves.easeOutCubic,
                          switchOutCurve: Curves.easeInCubic,
                          child: (_logoUrl != null && _logoUrl!.isNotEmpty)
                              ? KeyedSubtree(
                                  key: const ValueKey('logo'),
                                  child: CachedNetworkImage(
                                    imageUrl: _logoUrl!,
                                    fit: BoxFit.contain,
                                    fadeInDuration: const Duration(milliseconds: 140),
                                    errorWidget: (context, url, error) => _titleText(),
                                  ),
                                )
                              : KeyedSubtree(
                                  key: const ValueKey('text-title'),
                                  child: _titleText(),
                                ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(height: 18, child: Center(child: _metaLine())),
                    const SizedBox(height: 18),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _wrap(_playButton(), widget.onPlay, autofocus: true),
                        const SizedBox(width: 10),
                        _wrap(
                          _circleBtn(
                            widget.inList ? Icons.check_rounded : Icons.add_rounded,
                            widget.onToggleList,
                            active: widget.inList,
                            semanticLabel: widget.inList
                                ? 'Remove from My List'
                                : 'Add to My List',
                          ),
                          widget.onToggleList,
                        ),
                        const SizedBox(width: 10),
                        _wrap(
                          _circleBtn(
                            Icons.info_outline_rounded,
                            widget.onInfo,
                            semanticLabel: 'Details',
                          ),
                          widget.onInfo,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _titleText() {
    final seed = widget.item.tmdbId ?? widget.item.id;
    final accent = _artColor ?? Colors.white;
    return cinioFallbackTitle(
      title: widget.item.title,
      seed: seed,
      accent: accent,
      fontSize: 28.5,
      maxLines: 2,
    );
  }

  /// If a [widget.wrapButton] decorator was provided (TV), wraps [w] with it;
  /// otherwise returns [w] unchanged — phone behaviour is exact.
  Widget _wrap(Widget w, VoidCallback cb, {bool autofocus = false}) {
    final decorator = widget.wrapButton;
    return decorator != null ? decorator(w, cb, autofocus: autofocus) : w;
  }

  Widget _metaLine() {
    return FutureBuilder<HeroMeta?>(
      future: widget.metaFuture,
      builder: (context, snap) {
        final m = snap.data;
        final children = <Widget>[];
        final rating = m?.rating ?? widget.item.rating;
        final year = (m?.year ?? widget.item.year)?.trim();
        final genres = (m?.genres.isNotEmpty == true ? m!.genres : widget.item.genres);
        if (rating != null && rating > 0) {
          children.add(Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.star_rounded, color: Color(0xFFFFC107), size: 15),
              const SizedBox(width: 4),
              Text(rating.toStringAsFixed(1)),
            ],
          ));
        }
        if (year != null && year.isNotEmpty) {
          children.add(Text(year));
        }
        for (final genre in genres.take(3)) {
          children.add(Text(genre));
        }
        if ((m?.episodeCount ?? 0) > 1) {
          children.add(Text(
            '${m!.episodeCount} ${widget.reading ? 'Chapters' : 'Episodes'}',
          ));
        }
        if (children.isEmpty) return const SizedBox.shrink();
        return SizedBox(
          height: 20,
          child: Center(
            child: DefaultTextStyle(
              style: AppText.caption.copyWith(
                color: Colors.white.withValues(alpha: 0.90),
                fontWeight: FontWeight.w600,
                letterSpacing: 0.15,
              ),
              child: Wrap(
                alignment: WrapAlignment.center,
                crossAxisAlignment: WrapCrossAlignment.center,
                spacing: 9,
                children: [
                  for (var i = 0; i < children.length; i++) ...[
                    if (i > 0)
                      Container(
                        width: 3,
                        height: 3,
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.48),
                          shape: BoxShape.circle,
                        ),
                      ),
                    children[i],
                  ],
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _playButton() {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: widget.onPlay,
        child: SizedBox(
          width: 138,
          height: 44,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                widget.reading
                    ? Icons.menu_book_rounded
                    : Icons.play_arrow_rounded,
                color: AppColors.bg,
                size: 20,
              ),
              SizedBox(width: 7),
              Text(
                widget.reading ? 'Read' : 'Play',
                style: TextStyle(
                  fontFamily: 'Inter',
                  color: AppColors.bg,
                  fontWeight: FontWeight.w700,
                  fontSize: 15,
                  letterSpacing: -0.2,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Inline glass circular action (My List / Info) sitting next to Play.
  Widget _circleBtn(
    IconData icon,
    VoidCallback onTap, {
    bool active = false,
    String? semanticLabel,
  }) {
    return Semantics(
      button: true,
      label: semanticLabel,
      child: GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.14),
            shape: BoxShape.circle,
            border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
          ),
          child: Icon(
            icon,
            color: active ? AppColors.accent : Colors.white,
            size: 21,
          ),
        ),
      ),
    );
  }
}
