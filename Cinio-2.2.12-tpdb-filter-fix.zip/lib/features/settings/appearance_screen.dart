import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../../core/ui/settings_widgets.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';

import '../../core/di/injector.dart';
import '../../core/playback/playback_prefs.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text.dart';
import '../../core/theme/theme_controller.dart';
import '../../core/ui/animation_prefs.dart';
import '../../core/ui/nav_prefs.dart';

/// Dedicated Appearance page (Aniyomi-style): accent colour as preview cards
/// (+ a Custom colour picker), a pure-black AMOLED toggle, and the Home banner
/// animation style. Every option defaults to the current look, so an untouched
/// install is unchanged.
class AppearanceScreen extends StatefulWidget {
  const AppearanceScreen({super.key});

  @override
  State<AppearanceScreen> createState() => _AppearanceScreenState();
}

class _AppearanceScreenState extends State<AppearanceScreen> {
  /// Android 12+ only. Resolved once; the row stays hidden everywhere else
  /// rather than showing a switch that couldn't do anything.
  bool _wallpaperSupported = false;

  @override
  void initState() {
    super.initState();
    ThemeController.supported().then((ok) {
      if (mounted && ok) setState(() => _wallpaperSupported = true);
    });
  }

  bool get _accentIsCustom => !ThemeController.accentPresets.any(
    (p) => p.$2.toARGB32() == AppColors.accent.toARGB32(),
  );

  Future<void> _pickCustom() async {
    var temp = AppColors.accent;
    final result = await showDialog<Color>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: Text('Custom colour', style: AppText.headline),
        content: SingleChildScrollView(
          child: ColorPicker(
            pickerColor: temp,
            onColorChanged: (c) => temp = c,
            enableAlpha: false,
            displayThumbColor: true,
            paletteType: PaletteType.hueWheel,
            labelTypes: const [],
            pickerAreaBorderRadius: BorderRadius.circular(12),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(
              'Cancel',
              style: TextStyle(color: AppColors.textSecondary),
            ),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, temp),
            child: Text('Apply', style: TextStyle(color: AppColors.accent)),
          ),
        ],
      ),
    );
    if (result != null) {
      await ThemeController.setAccent(result);
      if (mounted) setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final presets = ThemeController.accentPresets;
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: settingsAppBar('Appearance'),
      body: ListView(
        padding: const EdgeInsets.only(top: 4, bottom: 32),
        children: [
          // ── Accent colour ─────────────────────────────────────────────────
          // The swatch strip stays exactly as it was, and stays first.
          const SettingsSectionLabel('Accent colour', first: true),
          _blurb(
            'The highlight colour used across buttons, chips, progress and '
            'selected items.',
          ),
          Opacity(
            // Dimmed while the wallpaper is choosing — the swatches still work,
            // and tapping one takes you back to picking by hand.
            opacity: ThemeController.materialYou ? 0.4 : 1,
            child: SizedBox(
              height: 100,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                // Align with SettingsCard's margin so the strip lines up with
                // the cards below it.
                padding: const EdgeInsets.symmetric(horizontal: 16),
                clipBehavior: Clip.none,
                itemCount: presets.length + 1,
                separatorBuilder: (_, _) => const SizedBox(width: 10),
                itemBuilder: (_, i) {
                  if (i == presets.length) {
                    return _CustomCard(
                      selected: _accentIsCustom,
                      currentColor: AppColors.accent,
                      onTap: () {
                        if (_blockedByMaterialYou()) return;
                        _pickCustom();
                      },
                    );
                  }
                  final (name, color) = presets[i];
                  return _AccentCard(
                    name: name,
                    color: color,
                    selected:
                        !_accentIsCustom &&
                        AppColors.accent.toARGB32() == color.toARGB32(),
                    isDefault: ThemeController.isDefault(color),
                    onTap: () async {
                      if (_blockedByMaterialYou()) return;
                      await ThemeController.setAccent(color);
                      if (mounted) setState(() {});
                    },
                  );
                },
              ),
            ),
          ),
          // ── Theme ─────────────────────────────────────────────────────────
          const SettingsSectionLabel('Theme'),
          SettingsCard(
            children: [
              if (_wallpaperSupported)
                _switchTile(
                  icon: Icons.palette_outlined,
                  title: 'Material You',
                  // Doubles as the hint that the strip above still works.
                  subtitle: 'Colours from your wallpaper',
                  value: ThemeController.materialYou,
                  onChanged: ThemeController.setMaterialYou,
                ),
              _switchTile(
                icon: Icons.dark_mode_outlined,
                title: 'Pure black background',
                subtitle: 'True black for OLED',
                value: ThemeController.amoled,
                onChanged: ThemeController.setAmoled,
              ),
            ],
          ),

          // ── Display ───────────────────────────────────────────────────────
          const SettingsSectionLabel('Display'),
          SettingsCard(
            children: [
              _switchTile(
                icon: Icons.sell_outlined,
                title: 'Poster badges',
                subtitle: 'Quality and Sub/Dub badges',
                value: sl<PlaybackPrefs>().qualityBadges,
                onChanged: sl<PlaybackPrefs>().setQualityBadges,
              ),
              SettingsTile(
                icon: Icons.crop_portrait_outlined,
                title: 'Card style',
                subtitle: 'Shape of normal Home content rows',
                trailing: Text(
                  switch (sl<PlaybackPrefs>().homeCardStyle) {
                    'poster' => 'Poster',
                    'landscape' => 'Landscape',
                    _ => 'Adaptive',
                  },
                  style: AppText.caption,
                ),
                onTap: () async {
                  final current = sl<PlaybackPrefs>().homeCardStyle;
                  final picked = await showModalBottomSheet<String>(
                    context: context,
                    backgroundColor: AppColors.surface,
                    showDragHandle: true,
                    builder: (ctx) => SafeArea(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(20, 4, 20, 20),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Card style', style: AppText.headline),
                            const SizedBox(height: 8),
                            for (final option in const [
                              ('adaptive', 'Adaptive'),
                              ('poster', 'Poster'),
                              ('landscape', 'Landscape'),
                            ])
                              ListTile(
                                contentPadding: EdgeInsets.zero,
                                title: Text(option.$2),
                                trailing: current == option.$1
                                    ? Icon(Icons.check_rounded, color: AppColors.accent)
                                    : null,
                                onTap: () => Navigator.pop(ctx, option.$1),
                              ),
                          ],
                        ),
                      ),
                    ),
                  );
                  if (picked != null) {
                    await sl<PlaybackPrefs>().setHomeCardStyle(picked);
                    if (mounted) setState(() {});
                  }
                },
              ),
              SettingsTile(
                icon: Icons.people_outline_rounded,
                title: 'People card style',
                subtitle: 'How cast and performer rows are shown',
                trailing: Text(
                  sl<PlaybackPrefs>().peopleCardStyle == 'square'
                      ? 'Square'
                      : 'Circle',
                  style: AppText.caption,
                ),
                onTap: () async {
                  final current = sl<PlaybackPrefs>().peopleCardStyle;
                  final picked = await showModalBottomSheet<String>(
                    context: context,
                    backgroundColor: AppColors.surface,
                    showDragHandle: true,
                    builder: (ctx) => SafeArea(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(20, 4, 20, 20),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('People card style', style: AppText.headline),
                            const SizedBox(height: 8),
                            for (final option in const [('circle', 'Circle'), ('square', 'Square')])
                              ListTile(
                                contentPadding: EdgeInsets.zero,
                                title: Text(option.$2),
                                trailing: current == option.$1
                                    ? Icon(Icons.check_rounded, color: AppColors.accent)
                                    : null,
                                onTap: () => Navigator.pop(ctx, option.$1),
                              ),
                          ],
                        ),
                      ),
                    ),
                  );
                  if (picked != null) {
                    await sl<PlaybackPrefs>().setPeopleCardStyle(picked);
                    if (mounted) setState(() {});
                  }
                },
              ),
              _switchTile(
                icon: Icons.label_outline_rounded,
                title: 'Show navigation labels',
                subtitle: 'Show text below bottom navigation icons',
                value: sl<NavPrefs>().showNavigationLabels,
                onChanged: sl<NavPrefs>().setShowNavigationLabels,
              ),
              _switchTile(
                icon: Icons.auto_awesome_motion_outlined,
                title: 'Animate lists',
                subtitle: 'Cards fade in as you scroll',
                value: AnimationPrefs.listAnimations,
                onChanged: AnimationPrefs.setListAnimations,
              ),
              // Only meaningful while the animation is on.
              if (AnimationPrefs.listAnimations)
                SettingsTile(
                  icon: Icons.animation_outlined,
                  title: 'Animation style',
                  subtitle: _animStyleBlurb,
                  trailing: Text(_animStyleName, style: AppText.caption),
                  onTap: _pickAnimStyle,
                ),
            ],
          ),

        ],
      ),
    );
  }

  /// True when the wallpaper is choosing the accent, so a swatch tap can't
  /// apply. Says so rather than doing nothing — the swatches are dimmed, but a
  /// dim control that swallows taps is still confusing.
  bool _blockedByMaterialYou() {
    if (!ThemeController.materialYou) return false;
    // FToast, matching the shell's exit toast — the app doesn't use SnackBars.
    (FToast()..init(context)).showToast(
      gravity: ToastGravity.BOTTOM,
      toastDuration: const Duration(seconds: 2),
      child: Container(
        margin: const EdgeInsets.only(bottom: 40),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0xF01C1C1E),
          borderRadius: BorderRadius.circular(24),
        ),
        child: const Text(
          'Turn off Material You to pick a colour yourself',
          style: TextStyle(color: Colors.white, fontSize: 14),
        ),
      ),
    );
    return true;
  }

  /// Section description under a [SettingsSectionLabel], indented to match it.
  Widget _blurb(String text) => Padding(
    padding: const EdgeInsets.fromLTRB(28, 0, 22, 10),
    child: Text(text, style: AppText.caption),
  );

  /// A [SettingsTile] with a switch. The whole row toggles, which is how the
  /// rest of Settings behaves — the switch alone was a small target.
  Widget _switchTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required Future<void> Function(bool) onChanged,
  }) {
    Future<void> flip(bool v) async {
      await onChanged(v);
      if (mounted) setState(() {});
    }

    return SettingsTile(
      icon: icon,
      title: title,
      subtitle: subtitle,
      onTap: () => flip(!value),
      trailing: Switch.adaptive(
        value: value,
        activeThumbColor: AppColors.accent,
        onChanged: flip,
      ),
    );
  }

  static const List<(ListAnimStyle, String, String)> _animStyles = [
    (ListAnimStyle.rise, 'Rise', 'Lifts and fades in'),
    (ListAnimStyle.fade, 'Fade', 'Fades in, no movement'),
    (ListAnimStyle.zoom, 'Zoom', 'Scales up as it appears'),
  ];

  (ListAnimStyle, String, String) get _animStyle => _animStyles.firstWhere(
    (o) => o.$1 == AnimationPrefs.style,
    orElse: () => _animStyles.first,
  );
  String get _animStyleName => _animStyle.$2;
  String get _animStyleBlurb => _animStyle.$3;

  /// Style picker. Was three rows always on the page; a sheet keeps the screen
  /// short and matches how the other settings pickers behave.
  Future<void> _pickAnimStyle() async {
    final picked = await showModalBottomSheet<ListAnimStyle>(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
              child: Row(
                children: [Text('Animation style', style: AppText.headline)],
              ),
            ),
            const Divider(color: AppColors.hairline, height: 1),
            for (final (style, name, blurb) in _animStyles)
              ListTile(
                onTap: () => Navigator.pop(ctx, style),
                title: Text(
                  name,
                  style: AppText.body.copyWith(color: AppColors.textPrimary),
                ),
                subtitle: Text(blurb, style: AppText.caption),
                trailing: AnimationPrefs.style == style
                    ? Icon(Icons.check, color: AppColors.accent)
                    : null,
              ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
    if (picked == null) return;
    await AnimationPrefs.setStyle(picked);
    if (mounted) setState(() {});
  }
}

/// A single accent option, rendered as a mini app preview in that colour.
class _AccentCard extends StatelessWidget {
  const _AccentCard({
    required this.name,
    required this.color,
    required this.selected,
    required this.isDefault,
    required this.onTap,
  });

  final String name;
  final Color color;
  final bool selected;
  final bool isDefault;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 98,
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: selected ? color : AppColors.hairline,
              width: selected ? 2 : 1,
            ),
          ),
          padding: const EdgeInsets.all(8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(height: 58, child: _preview(color, selected)),
              const SizedBox(height: 8),
              Text(
                isDefault ? 'Default' : name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: AppText.caption.copyWith(
                  color: selected
                      ? AppColors.textPrimary
                      : AppColors.textSecondary,
                  fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// The "Custom" option — opens a colour wheel. Preview shows a rainbow sweep,
/// or the current custom colour when one is active.
class _CustomCard extends StatelessWidget {
  const _CustomCard({
    required this.selected,
    required this.currentColor,
    required this.onTap,
  });
  final bool selected;
  final Color currentColor;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 98,
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: selected ? currentColor : AppColors.hairline,
              width: selected ? 2 : 1,
            ),
          ),
          padding: const EdgeInsets.all(8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                height: 58,
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    gradient: const SweepGradient(
                      colors: [
                        Color(0xFFFF4D57),
                        Color(0xFFFFB020),
                        Color(0xFF32D583),
                        Color(0xFF3DD6D0),
                        Color(0xFF4D8DFF),
                        Color(0xFF9B6DFF),
                        Color(0xFFFF5FA2),
                        Color(0xFFFF4D57),
                      ],
                    ),
                  ),
                  child: Center(
                    child: Container(
                      padding: const EdgeInsets.all(7),
                      decoration: BoxDecoration(
                        color: AppColors.surface2,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        selected ? Icons.check_rounded : Icons.colorize_rounded,
                        color: AppColors.textPrimary,
                        size: 18,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Custom',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: AppText.caption.copyWith(
                  color: selected
                      ? AppColors.textPrimary
                      : AppColors.textSecondary,
                  fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

Widget _preview(Color color, bool selected) => Stack(
  children: [
    Container(
      width: double.infinity,
      height: double.infinity,
      decoration: BoxDecoration(
        color: AppColors.surface2,
        borderRadius: BorderRadius.circular(10),
      ),
      padding: const EdgeInsets.all(9),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Container(
            height: 5,
            width: 34,
            decoration: BoxDecoration(
              color: AppColors.textTertiary,
              borderRadius: BorderRadius.circular(3),
            ),
          ),
          Row(
            children: [
              Container(
                width: 40,
                height: 13,
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(7),
                ),
              ),
              const SizedBox(width: 6),
              Container(
                width: 13,
                height: 13,
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.22),
                  shape: BoxShape.circle,
                ),
              ),
            ],
          ),
          Container(
            height: 4,
            width: 58,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.55),
              borderRadius: BorderRadius.circular(3),
            ),
          ),
        ],
      ),
    ),
    if (selected)
      Positioned(
        top: 3,
        right: 3,
        child: Container(
          padding: const EdgeInsets.all(2),
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
            border: Border.all(color: AppColors.surface2, width: 2),
          ),
          child: const Icon(Icons.check_rounded, color: Colors.white, size: 11),
        ),
      ),
  ],
);
