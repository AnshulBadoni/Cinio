import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'package:url_launcher/url_launcher.dart';

import '../../core/app_mode.dart';
import '../../core/di/injector.dart';
import '../../core/mode/content_mode.dart';
import '../../core/mode/content_mode_cubit.dart';
import '../../core/models/media_detail.dart';
import '../../core/models/media_item.dart';
import '../../core/models/person.dart';
import '../../core/models/provider_info.dart';
import '../../core/metadata/tmdb_discover_service.dart';
import '../../core/metadata/theporndb.dart';
import '../../core/playback/my_list.dart';
import '../../core/playback/playback_prefs.dart';
import '../../core/playback/resume_store.dart';
import '../../core/playback/search_history.dart';
import '../../core/playback/search_prefs.dart';
import '../../core/playback/search_source_prefs.dart';
import '../../core/playback/source_health_store.dart' show SourceOutcome;
import '../../core/playback/title_prefs.dart';
import '../../core/playback/watch_history.dart';
import '../../core/prefs/catalog_source_prefs.dart';
import '../../core/repository/source_repository.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text.dart';
import '../../core/ui/media_info_sheet.dart';
import '../../core/ui/row_skeleton.dart';
import '../../core/ui/source_switcher.dart';
import '../../core/ui/poster_card.dart';
import '../../core/ui/reveal_item.dart';
import '../../core/ui/states.dart';
import '../../core/aniyomi/aniyomi_filters.dart';
import '../../core/mihon/mihon_filters.dart';
import '../aniyomi/aniyomi_filter_sheet.dart';
import '../mihon/mihon_filter_sheet.dart';
import '../auth/auth_screens.dart';
import '../detail/detail_screen.dart';
import '../people/person_page.dart';
import '../player/player_screen.dart';
import '../sources/zangetsu_sources_screen.dart';
import 'search_screen_tv.dart';
import 'see_all_screen.dart';
import '../search/bloc/search_bloc.dart';
import '../search/bloc/search_event.dart';
import '../search/bloc/search_state.dart';

/// Dedicated search screen pushed from the Home header search icon.
class SearchScreen extends StatelessWidget {
  const SearchScreen({
    super.key,
    this.initialQuery,
    this.showBack = true,
    this.focusSignal,
  });

  final String? initialQuery;

  /// When [false] the screen is embedded as a bottom-nav tab and the back
  /// arrow is hidden (also suppresses autofocus on launch).
  final bool showBack;

  /// Bumped by the shell each time the Search tab is selected, so the embedded
  /// tab can auto-focus its field without stealing focus while it sits idle in
  /// the IndexedStack. Null for the pushed (showBack) variant.
  final ValueListenable<int>? focusSignal;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) {
        final bloc = SearchBloc(
          repo: sl<SourceRepository>(),
          history: sl<SearchHistory>(),
        )..add(const SearchStarted());
        final q = initialQuery?.trim();
        // An initial query (e.g. "see all results" from Home) runs the full
        // search straight away rather than waiting for the user to type.
        if (q != null && q.isNotEmpty) bloc.add(SearchRunRequested(q));
        return bloc;
      },
      // On Android TV, hand off to the D-pad-optimised layout. The BlocProvider
      // above is still the provider for both paths — SearchScreenTv reads the
      // same SearchBloc from context, so no duplication of bloc creation.
      child: sl<AppMode>().isTv
          ? SearchScreenTv(
              initialQuery: initialQuery,
              history: sl<SearchHistory>(),
            )
          : _SearchView(
              initialQuery: initialQuery,
              showBack: showBack,
              focusSignal: focusSignal,
            ),
    );
  }
}

class _SearchView extends StatefulWidget {
  const _SearchView({
    this.initialQuery,
    required this.showBack,
    this.focusSignal,
  });

  final String? initialQuery;
  final bool showBack;
  final ValueListenable<int>? focusSignal;

  @override
  State<_SearchView> createState() => _SearchViewState();
}

/// Max posters shown in a per-source section before it collapses to a "See all"
/// link. Picked to fill a few grid rows / a comfortable horizontal row without
/// the section dominating the screen.
const int _kSourcePreviewCap = 12;

/// Plain-English reason a source failed, from the outcome the repository
/// already classified (see `SourceRepository._outcomeFromError`).
///
/// Deliberately says what the user can act on rather than naming the
/// mechanism — "blocked" tells them to try another source, a stack trace
/// doesn't.
String outcomeReason(SourceOutcome outcome) => switch (outcome) {
  SourceOutcome.timeout => 'Timed out',
  SourceOutcome.blocked => 'Blocked by the site',
  _ => "Couldn't be reached",
};

IconData _outcomeIcon(SourceOutcome outcome) => switch (outcome) {
  SourceOutcome.timeout => Icons.hourglass_empty_rounded,
  SourceOutcome.blocked => Icons.shield_outlined,
  _ => Icons.error_outline_rounded,
};

class _SearchViewState extends State<_SearchView>
    with TickerProviderStateMixin {
  late final TextEditingController _controller;
  final _focusNode = FocusNode();
  final _repo = sl<SourceRepository>();
  final _myList = sl<MyListStore>();
  final _history = sl<SearchHistory>();
  final _searchPrefs = sl<SearchPrefs>();
  final _discoverScrollController = ScrollController();

  /// Owns the ecosystem [TabBar]'s controller — see [_ecoTabControllerFor].
  TabController? _ecoTabController;

  /// [_repo.loadedSources] narrowed to the active content mode. Anime narrows
  /// too — it used to short-circuit to the unfiltered list, which meant manga
  /// (`mihon:`) and novel (`lnr:`) sources were searched and rendered while in
  /// anime mode. Keep this in step with `SearchBloc._modeSources`, which drives
  /// the actual fan-out; this copy drives the ecosystem tabs and the pending
  /// skeletons, so a mismatch shows up as skeletons for sources that are never
  /// queried.
  List<({String id, String name})> get _modeSources {
    final mode = sl<ContentModeCubit>().state;
    return filterSourcesForMode(
      {for (final s in _repo.loadedSources) s.id: s},
      mode,
      (s) => sourceTypeOf(s.id),
    ).values.toList();
  }

  @override
  void initState() {
    super.initState();
    _discoverScrollController.addListener(_onDiscoverScroll);
    _controller = TextEditingController(text: widget.initialQuery ?? '');
    widget.focusSignal?.addListener(_onFocusSignal);
  }

  /// Focus the field when the Search tab is (re)selected so the keyboard is
  /// ready. Defers a frame so it runs after the IndexedStack reveals the tab.
  void _onFocusSignal() {
    if (!mounted) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _focusNode.requestFocus();
    });
  }

  void _onDiscoverScroll() {
    if (!_discoverScrollController.hasClients || !mounted) return;
    final position = _discoverScrollController.position;
    // Use extentAfter rather than maxScrollExtent - threshold. The latter can
    // fail on short grids because the threshold becomes negative; extentAfter
    // directly answers the question we care about: how much content remains?
    if (position.extentAfter > 900) return;
    final bloc = context.read<SearchBloc>();
    final state = bloc.state;
    final canDiscover = state.query.trim().isEmpty &&
        !state.discoverLoadingMore &&
        !state.discoverAtEnd &&
        state.status != SearchStatus.loading;
    final canSearch = state.query.trim().isNotEmpty &&
        state.catalogSource == SearchCatalogSource.tmdb &&
        !state.searchLoadingMore &&
        !state.searchAtEnd &&
        state.status != SearchStatus.loading;
    if (canDiscover || canSearch) {
      bloc.add(const SearchDiscoverMore());
    }
  }

  @override
  void dispose() {
    widget.focusSignal?.removeListener(_onFocusSignal);
    _discoverScrollController.dispose();
    _controller.dispose();
    _focusNode.dispose();
    _ecoTabController?.dispose();
    super.dispose();
  }

  // ── Query helpers ─────────────────────────────────────────────────────────
  /// Fills the field with [q] and runs the full search now (suggestion /
  /// recent / submit). Also dismisses the keyboard so results are unobstructed.
  void _runQuery(String q) {
    _controller.value = TextEditingValue(
      text: q,
      selection: TextSelection.collapsed(offset: q.length),
    );
    FocusScope.of(context).unfocus();
    context.read<SearchBloc>().add(SearchRunRequested(q));
  }

  void _clear() {
    _controller.clear();
    context.read<SearchBloc>().add(const SearchQueryChanged(''));
  }

  String _typeLabel(ProviderType t) =>
      t == ProviderType.movie ? 'Movie' : 'Anime';

  Future<MediaDetail?> _detailOf(String url, String sourceId) async {
    try {
      return await _repo.detail(url, sourceId: sourceId);
    } catch (_) {
      return null;
    }
  }

  List<String> _tagsFor(MediaItem m) {
    // Quality is NOT here — it has its own top-right corner on the card.
    final t = <String>[];
    if ((m.dubCount ?? 0) > 0) t.add('DUB');
    if ((m.subCount ?? 0) > 0 && t.length < 2) t.add('SUB');
    if (t.isEmpty && m.sourceId == 'tmdb:catalog') {
      if (m.tmdbIsAnime) {
        t.add('ANIME');
      } else if (m.tmdbIsTv) {
        t.add('SERIES');
      } else {
        t.add('MOVIE');
      }
    } else if (t.isEmpty && m.type == ProviderType.movie) {
      t.add('MOVIE');
    }
    return t;
  }

  Future<void> _openDetail(MediaItem item) async {
    if (!mounted) return;
    if (item.sourceId == 'tpdb:performer') {
      final raw = item.id.replaceFirst('tpdb:performer:', '');
      Navigator.of(context).push(PersonPage.route(
        PersonRef(
          id: 0,
          externalId: raw,
          source: PersonSource.thePornDbPerformer,
          name: item.title,
          photo: item.cover,
        ),
        sourceId: item.sourceId,
      ));
      return;
    }
    if (item.sourceId == 'tpdb:studio') {
      final raw = item.id.replaceFirst('tpdb:studio:', '');
      Navigator.of(context).push(PersonPage.route(
        PersonRef(
          id: 0,
          externalId: raw,
          source: PersonSource.thePornDbStudio,
          name: item.title,
          photo: item.cover,
        ),
        sourceId: item.sourceId,
      ));
      return;
    }
    MediaDetail? catalogDetail;
    if (item.sourceId == 'tmdb:catalog') {
      try { catalogDetail = await sl<TmdbDiscoverService>().movieDetail(item); } catch (_) {}
    } else if (item.sourceId == 'tpdb:catalog' && item.id.startsWith('tpdb:movie:')) {
      try { catalogDetail = await sl<ThePornDb>().movieDetail(item); } catch (_) {}
    }
    if (!mounted) return;
    Navigator.push(context, DetailScreen.route(item, catalogDetail: catalogDetail)).then((_) { if (mounted) setState(() {}); });
  }

  /// Opens the full-grid view of ONE source's complete results for the current
  /// query. Reuses the home "See All" screen (with search-style poster tags) so
  /// tapping a result opens its Detail exactly like the search grid.
  void _openSourceSeeAll(SourceResultGroup g) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => SeeAllScreen(
          title: g.sourceName,
          items: g.items,
          tagsFor: _tagsFor,
          onTap: _openDetail,
          onLongPress: _showInfo,
          // Search results are a fixed, already-fetched set — no pagination.
          onLoadMore: null,
        ),
      ),
    ).then((_) {
      if (mounted) setState(() {});
    });
  }

  /// Opens the Aniyomi per-source filter sheet for [sourceId].
  ///
  /// Fetches the filter schema, shows the sheet, and dispatches
  /// [SearchSourceFiltersApplied] with the selection JSON when the user taps
  /// Apply. A brief SnackBar informs the user when the source has no filters.
  Future<void> _openAniFilters(String sourceId) async {
    final stored = context
        .read<SearchBloc>()
        .state
        .aniFiltersBySource[sourceId];
    final List<AniyomiFilter> filters = (stored != null && stored.isNotEmpty)
        ? AniyomiFilters.parse(stored)
        : await _repo.aniFilters(sourceId);
    if (!mounted) return;
    if (filters.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('This source has no filters')),
      );
      return;
    }
    // Drop focus first. The search field autofocuses on open and keeps focus
    // behind the modal, so the keyboard can reappear over the sheet — which
    // shrinks it to a sliver and then dismisses it, losing the selection.
    FocusScope.of(context).unfocus();
    final result = await showAniyomiFilterSheet(context, filters);
    if (result == null || !mounted) return;
    context.read<SearchBloc>().add(
      SearchSourceFiltersApplied(
        sourceId,
        AniyomiFilters.toSelectionJson(result),
      ),
    );
  }

  /// Mihon twin of [_openAniFilters] — same flow, [MihonFilter] types and
  /// `_repo.mihonFilters`/`showMihonFilterSheet` instead of the Aniyomi ones.
  Future<void> _openMihonFilters(String sourceId) async {
    final stored = context
        .read<SearchBloc>()
        .state
        .mihonFiltersBySource[sourceId];
    final List<MihonFilter> filters = (stored != null && stored.isNotEmpty)
        ? MihonFilters.parse(stored)
        : await _repo.mihonFilters(sourceId);
    if (!mounted) return;
    if (filters.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('This source has no filters')),
      );
      return;
    }
    // Drop focus first — see [_openAniFilters] for why.
    FocusScope.of(context).unfocus();
    final result = await showMihonFilterSheet(context, filters);
    if (result == null || !mounted) return;
    context.read<SearchBloc>().add(
      SearchSourceFiltersApplied(
        sourceId,
        MihonFilters.toSelectionJson(result),
      ),
    );
  }

  Future<MediaItem?> _resolveCatalogItem(MediaItem item) async {
    if (item.sourceId != 'tmdb:catalog' && !item.sourceId.startsWith('tpdb:')) return item;
    return item;
  }

  Future<void> _play(MediaItem item) async {
    if (item.sourceId == 'tpdb:performer' || item.sourceId == 'tpdb:studio') {
      _openDetail(item);
      return;
    }
    final resolved = await _resolveCatalogItem(item);
    if (!mounted) return;
    if (resolved == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('No playable result found for ${item.title}')),
      );
      return;
    }
    final category =
        sl<TitlePrefsStore>().category(resolved.sourceId, resolved.url) ??
        sl<PlaybackPrefs>().defaultCategory;
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PlayerScreen(
          sourceId: resolved.sourceId,
          episodesResolver: () =>
              _repo.episodes(resolved.url, sourceId: resolved.sourceId),
          resume: sl<ResumeStore>(),
          resolveSources: (u) =>
              _repo.sources(u, sourceId: resolved.sourceId, fast: true),
          history: sl<WatchHistory>(),
          showTitle: resolved.title,
          cover: resolved.cover ?? item.cover,
          coverHeaders: resolved.coverHeaders ?? item.coverHeaders,
          showUrl: resolved.url,
          category: category,
          malId: resolved.malId,
          scrobbleTitle: resolved.type == ProviderType.anime ? resolved.title : null,
        ),
      ),
    );
    if (mounted) setState(() {});
  }

  Future<void> _showInfo(MediaItem item) async {
    if (item.sourceId == 'tpdb:performer' || item.sourceId == 'tpdb:studio') {
      _openDetail(item);
      return;
    }
    final resolved = await _resolveCatalogItem(item);
    if (!mounted) return;
    final target = resolved ?? item;
    if (resolved == null && item.sourceId == 'tmdb:catalog') {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('No result found for ${item.title}')),
      );
      return;
    }
    showMediaInfoSheet(
      context,
      title: target.title,
      englishTitle: target.englishTitle,
      cover: target.cover ?? item.cover,
      headers: target.coverHeaders ?? item.coverHeaders,
      typeLabel: _typeLabel(target.type),
      subCount: target.subCount,
      dubCount: target.dubCount,
      detail: _detailOf(target.url, target.sourceId),
      inMyList: _myList.contains(target),
      onPlay: () => _play(target),
      onOpenDetail: () => _openDetail(target),
      onToggleMyList: () async {
        if (!requireLogin(context, action: 'add to My List')) {
          return _myList.contains(target);
        }
        await _myList.toggle(target);
        if (mounted) setState(() {});
        return _myList.contains(target);
      },
    );
  }

  // ── Filters (sort + content type + audio + genre + sources) ────────────────
  /// Opens the single, merged filter sheet: sort, content type + audio
  /// (anime mode only), genre, plus the categorised "search in these sources"
  /// list behind its own sub-sheet. Apply re-runs the current query so toggles
  /// take effect immediately.
  Future<void> _openFilterSheet(BuildContext context) async {
    final bloc = context.read<SearchBloc>();
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppColors.surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) =>
          BlocProvider.value(value: bloc, child: const _SearchFilterSheet()),
    );
    // Re-run so source toggles drop out / reappear (content-type filtering is
    // applied client-side and updates live via the bloc, but a fresh run also
    // picks up newly-enabled sources).
    if (bloc.state.query.trim().isNotEmpty) {
      bloc.add(const SearchSubmitted());
    }
  }

  /// Search/Discover always uses a stable 3-column poster grid. Keeping the
  /// layout fixed avoids coupling this screen to the global poster-size
  /// preference and keeps Search/Discover predictable across devices.
  static const int _searchGridColumns = 3;

  double _searchGridCellWidth() {
    final width = MediaQuery.sizeOf(context).width;
    const horizontal = 32.0;
    const gap = 12.0;
    return (width - horizontal - (gap * (_searchGridColumns - 1))) /
        _searchGridColumns;
  }

  @override
  Widget build(BuildContext context) {
    // sizeOf (not MediaQuery.of) so this rebuilds only when the screen size
    // actually changes, not on every viewInsets change (e.g. every keyboard
    // animation frame).
    final cellW = _searchGridCellWidth();
    // Computed once per outer build, not once per BlocBuilder rebuild below
    // (each fires on every search state emission during a live fan-out).
    final modeSources = _modeSources;

    return Scaffold(
      backgroundColor: AppColors.bg,
      // bottom: false — the shell's floating dock overlays the content
      // (extendBody); a full SafeArea would clip results at the dock's edge.
      body: SafeArea(
        bottom: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _searchBar(),
            const SizedBox(height: 12),
            // Source line — what's being searched, one line of text, tap to
            // open the source picker. Shown idle too, so scope is always known.
            // Control row — ecosystem tabs (or a result count once scoped to a
            // single source) on the left, sort + filter actions on the right.
            _controlRow(modeSources),
            // Per-source result pills — direct jump to one source's results.
            _sourcePillsRow(),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Divider(
                height: 1,
                thickness: 1,
                color: AppColors.hairline,
              ),
            ),
            const SizedBox(height: 6),
            Expanded(
              child: BlocBuilder<SearchBloc, SearchState>(
                builder: (context, state) {
                  // While typing (before a search runs), show the live
                  // suggestion list instead of the idle/results body.
                  if (state.status != SearchStatus.success &&
                      state.suggestions.isNotEmpty) {
                    return _suggestionList(state.suggestions);
                  }
                  switch (state.status) {
                    case SearchStatus.idle:
                      return _idleView(state);
                    case SearchStatus.loading:
                      return const Padding(
                        padding: EdgeInsets.all(20),
                        child: SkeletonGrid(),
                      );
                    case SearchStatus.error:
                      return _errorView(state);
                    case SearchStatus.success:
                      // An empty query is Discover mode, not a provider-search
                      // result set. TMDB discovery stores its items in
                      // [discoverItems], so sending this state through
                      // [_resultsBody] made a successful Discover request look
                      // like "0 results for \"\"".
                      return state.query.trim().isEmpty
                          ? _idleView(state)
                          : _resultsBody(state, cellW, modeSources);
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Search bar ────────────────────────────────────────────────────────────
  Widget _searchBar() {
    return Padding(
      padding: EdgeInsets.fromLTRB(widget.showBack ? 4 : 16, 12, 16, 0),
      child: Row(
        children: [
          if (widget.showBack)
            IconButton(
              icon: const Icon(
                Icons.arrow_back_ios_new,
                color: Colors.white,
                size: 20,
              ),
              onPressed: () => Navigator.pop(context),
              tooltip: 'Back',
            ),
          Expanded(
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: AppColors.surface2,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  const SizedBox(width: 4),
                  // Tappable magnifier — runs the full search (same as Enter).
                  IconButton(
                    icon: const Icon(
                      Icons.search,
                      size: 20,
                      color: AppColors.textTertiary,
                    ),
                    tooltip: 'Search',
                    onPressed: () {
                      FocusScope.of(context).unfocus();
                      context.read<SearchBloc>().add(
                        SearchRunRequested(_controller.text),
                      );
                    },
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(
                      minWidth: 36,
                      minHeight: 36,
                    ),
                  ),
                  const SizedBox(width: 4),
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      focusNode: _focusNode,
                      autofocus: widget.showBack,
                      textInputAction: TextInputAction.search,
                      // Typing only updates suggestions — it never starts the
                      // heavy multi-source search.
                      onChanged: (text) => context.read<SearchBloc>().add(
                        SearchQueryChanged(text),
                      ),
                      // Enter / keyboard "search" runs the full search.
                      onSubmitted: (text) {
                        FocusScope.of(context).unfocus();
                        context.read<SearchBloc>().add(
                          SearchRunRequested(text),
                        );
                      },
                      style: AppText.body.copyWith(
                        color: AppColors.textPrimary,
                      ),
                      cursorColor: AppColors.accent,
                      decoration: const InputDecoration(
                        hintText: 'Search…',
                        hintStyle: AppText.body,
                        border: InputBorder.none,
                        isDense: true,
                        contentPadding: EdgeInsets.symmetric(vertical: 14),
                      ),
                    ),
                  ),
                  const SizedBox(width: 2),
                  _filterAction(),
                  const SizedBox(width: 2),
                  // Clear button (only when there's text).
                  ValueListenableBuilder<TextEditingValue>(
                    valueListenable: _controller,
                    builder: (context, value, _) => value.text.isEmpty
                        ? const SizedBox.shrink()
                        : IconButton(
                            icon: const Icon(
                              Icons.close_rounded,
                              size: 18,
                              color: AppColors.textTertiary,
                            ),
                            tooltip: 'Clear',
                            onPressed: _clear,
                            padding: EdgeInsets.zero,
                            constraints: const BoxConstraints(
                              minWidth: 32,
                              minHeight: 32,
                            ),
                          ),
                  ),
                  const SizedBox(width: 4),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }


  // ── Control row (ecosystem tabs / result count + sort + filter) ────────────
  /// Left: ecosystem tabs when searching all sources (unchanged strip), or a
  /// plain "N results" label once scoped to a single source (tabs are
  /// meaningless with one source). Right: sort + filter actions — relocated
  /// here from the search field so the field itself stays a plain text input.
  /// Unlike the old ecosystem-tabs band, this row never fully collapses: sort
  /// and filter must stay reachable in every state (idle included), exactly as
  /// they were when they lived inside the search bar.
  Widget _controlRow(List<({String id, String name})> modeSources) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 4, 0),
      child: SizedBox(
        height: 40,
        child: Row(
          children: [
            Expanded(child: _controlRowLeft(modeSources)),
          ],
        ),
      ),
    );
  }

  Widget _controlRowLeft(List<({String id, String name})> modeSources) {
    return BlocBuilder<SearchBloc, SearchState>(
      buildWhen: (p, c) =>
          p.status != c.status ||
          p.currentSourceOnly != c.currentSourceOnly ||
          p.catalogSource != c.catalogSource ||
          p.ecosystem != c.ecosystem ||
          p.suggestions != c.suggestions ||
          p.groups != c.groups ||
          p.contentFilter != c.contentFilter ||
          p.audioFilter != c.audioFilter ||
          p.genreFilter != c.genreFilter ||
          p.statusFilter != c.statusFilter,
      builder: (context, state) {
        if (state.currentSourceOnly) {
          if (state.status != SearchStatus.success) {
            return const SizedBox.shrink();
          }
          final n = state.totalCount;
          return Align(
            alignment: Alignment.centerLeft,
            child: Text(
              '$n result${n == 1 ? '' : 's'}',
              style: AppText.caption.copyWith(fontSize: 12.5),
            ),
          );
        }
        final showingSuggestions =
            state.status != SearchStatus.success &&
            state.suggestions.isNotEmpty;
        if (showingSuggestions || state.status != SearchStatus.success) {
          return const SizedBox.shrink();
        }
        return _searchTabs(state);
      },
    );
  }

  /// Filters action — sort + content type + audio + genre + which sources to
  /// search, all in one sheet now. Shows a small accent count badge (instead
  /// of only a tint) for how many of those are non-default, so the icon
  /// carries the same signal the old separate sort icon's tint used to.
  Widget _filterAction() {
    return BlocBuilder<SearchBloc, SearchState>(
      buildWhen: (p, c) =>
          p.sort != c.sort ||
          p.contentFilter != c.contentFilter ||
          p.audioFilter != c.audioFilter ||
          p.genreFilter != c.genreFilter ||
          p.statusFilter != c.statusFilter ||
          p.currentSourceOnly != c.currentSourceOnly,
      builder: (context, state) => ListenableBuilder(
        listenable: sl<SearchSourcePrefs>(),
        builder: (context, _) {
          // Source excludes only count as an active filter when actually
          // fanning out to all sources.
          final sourceExcluded =
              !state.currentSourceOnly &&
              sl<SearchSourcePrefs>().excluded.isNotEmpty;
          final count = state.activeFilterCount + (sourceExcluded ? 1 : 0);
          return _iconWithBadge(
            icon: Icons.tune_rounded,
            tooltip: 'Filters',
            count: count,
            onPressed: () => _openFilterSheet(context),
          );
        },
      ),
    );
  }

  /// A control-row icon button with a small accent count badge in the corner
  /// when [count] > 0 — used by [_filterAction] to surface how many
  /// sort/type/audio/genre/source selections are non-default at a glance,
  /// instead of a bare on/off tint.
  Widget _iconWithBadge({
    required IconData icon,
    required String tooltip,
    required int count,
    required VoidCallback onPressed,
  }) {
    return SizedBox(
      width: 36,
      height: 36,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          IconButton(
            icon: Icon(
              icon,
              size: 20,
              color: count > 0 ? AppColors.accent : AppColors.textTertiary,
            ),
            tooltip: tooltip,
            onPressed: onPressed,
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
          ),
          if (count > 0)
            Positioned(
              top: 3,
              right: 3,
              child: IgnorePointer(
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 4,
                    vertical: 1,
                  ),
                  constraints: const BoxConstraints(minWidth: 14),
                  decoration: BoxDecoration(
                    color: AppColors.accent,
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(color: AppColors.surface, width: 1.5),
                  ),
                  child: Text(
                    '$count',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 9,
                      fontWeight: FontWeight.w700,
                      height: 1.3,
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  /// Per-source filter routing for [sourceId] by [sourceFilterEcosystemOf] —
  /// the tap handler for the section-header tune icon (or null to hide it)
  /// plus whether a selection is already stored (drives the active tint).
  /// Shared by both source-section headers.
  /// ([_sourceRow]/[_sourceGrid]) so the routing lives in exactly one place.
  ({VoidCallback? onFilter, bool active}) _sourceFilterFor(
    String sourceId,
    SearchState state,
  ) {
    return switch (sourceFilterEcosystemOf(sourceId)) {
      SourceFilterEcosystem.aniyomi => (
        onFilter: () => _openAniFilters(sourceId),
        active: state.aniFiltersBySource.containsKey(sourceId),
      ),
      SourceFilterEcosystem.mihon => (
        onFilter: () => _openMihonFilters(sourceId),
        active: state.mihonFiltersBySource.containsKey(sourceId),
      ),
      null => (onFilter: null, active: false),
    };
  }

  /// Per-source filter action (Aniyomi or Mihon). In single-source mode
  /// there's no per-source section header to host it (the old scope pill
  /// surfaced it beside itself for the same reason), so it lives here —
  /// shown only when scoped to a source with a per-source filter sheet; see
  /// [sourceFilterEcosystemOf].

  // ── Ecosystem tabs (All · Zangetsu · CloudStream · Aniyomi) ────────────────
  /// Real [TabBar]/[TabController] pair — same treatment as the History
  /// screen's tabs (`history_screen.dart:321`): sliding rounded accent
  /// underline + label-colour crossfade instead of a static border, so
  /// switching tabs actually animates. [isScrollable] + [TabAlignment.start]
  /// keep it left-anchored regardless of how many tabs are present. "All"
  /// (first, default) applies no filter — selecting a tab is a pure view
  /// filter over already-fetched groups; see [SearchEcosystemChanged].
  Widget _searchTabs(SearchState state) {
    final isProviders = state.catalogSource == SearchCatalogSource.providers;
    final tabs = const ['All', 'Providers'];
    final selectedIndex = isProviders ? 1 : 0;
    final controller = _searchTabControllerFor(tabs.length, selectedIndex);
    return TabBar(
      controller: controller,
      isScrollable: true,
      tabAlignment: TabAlignment.start,
      padding: EdgeInsets.zero,
      labelPadding: const EdgeInsets.only(right: 20),
      dividerColor: Colors.transparent,
      dividerHeight: 0,
      indicatorSize: TabBarIndicatorSize.label,
      indicator: UnderlineTabIndicator(
        borderRadius: const BorderRadius.all(Radius.circular(2)),
        borderSide: BorderSide(width: 3, color: AppColors.accent),
        insets: const EdgeInsets.symmetric(horizontal: -6),
      ),
      labelColor: AppColors.accent,
      unselectedLabelColor: AppColors.textSecondary,
      labelStyle: const TextStyle(
        fontFamily: 'Inter',
        fontSize: 13,
        fontWeight: FontWeight.w700,
      ),
      unselectedLabelStyle: const TextStyle(
        fontFamily: 'Inter',
        fontSize: 13,
        fontWeight: FontWeight.w600,
      ),
      overlayColor: WidgetStateProperty.all(Colors.transparent),
      onTap: (i) {
        if (i == 1) {
          context.read<SearchBloc>().add(const SearchCatalogSourceChanged('providers'));
        } else {
          final pref = sl<CatalogSourcePrefs>().source;
          final catName = switch (pref) {
            CatalogSource.thePornDb => 'theporndb',
            CatalogSource.mixed => 'mixed',
            _ => 'tmdb',
          };
          context.read<SearchBloc>().add(SearchCatalogSourceChanged(catName));
        }
      },
      tabs: [for (final t in tabs) Tab(text: t)],
    );
  }

  TabController _searchTabControllerFor(int length, int index) {
    if (_ecoTabController == null || _ecoTabController!.length != length) {
      _ecoTabController?.dispose();
      _ecoTabController = TabController(
        length: length,
        vsync: this,
        initialIndex: index,
      );
    } else if (_ecoTabController!.index != index) {
      _ecoTabController!.index = index;
    }
    return _ecoTabController!;
  }

  // ── Per-source result pills (jump straight to one source) ──────────────────
  /// Recovered from the pre-redesign source-chip row (`_filterChips`/`_chip`,
  /// deleted when the grouped grid went 4-up) via `git show
  /// HEAD:lib/features/home/search_screen.dart`. Same selection logic
  /// byte-for-byte: [SearchState.sourceFilter] is a pure view filter over
  /// already-fetched [SearchState.groups] via [SearchSourceFilterChanged] —
  /// it never re-runs the search. [SearchState.sourceChipGroups] already
  /// narrows to the active ecosystem tab, so this row can't disagree with the
  /// tabs above it: switching ecosystems resets the pill selection back to
  /// "All" the same way the bloc already resets it on a fresh search or scope
  /// change (see `SearchBloc._onEcosystemChanged`).
  Widget _sourcePillsRow() {
    return BlocBuilder<SearchBloc, SearchState>(
      buildWhen: (p, c) =>
          p.groups != c.groups ||
          p.sourceFilter != c.sourceFilter ||
          p.currentSourceOnly != c.currentSourceOnly ||
          p.contentFilter != c.contentFilter ||
          p.audioFilter != c.audioFilter ||
          p.genreFilter != c.genreFilter ||
          p.statusFilter != c.statusFilter ||
          p.ecosystem != c.ecosystem ||
          p.suggestions != c.suggestions ||
          p.status != c.status,
      builder: (context, state) {
        final showingSuggestions =
            state.status != SearchStatus.success &&
            state.suggestions.isNotEmpty;
        // Keep the row while a source pill is selected, so a selection that
        // filters down to nothing doesn't also hide the pills needed to undo
        // it. Base "enough sources to filter" on the sources that RETURNED
        // results, not the content-filtered view.
        final hasSelection = state.sourceFilter != kAllSources;
        // Computed once here instead of once for the length check and again
        // inside _filterChips.
        final chipGroups = state.sourceChipGroups;
        if (state.currentSourceOnly ||
            showingSuggestions ||
            state.status != SearchStatus.success ||
            (chipGroups.length < 2 && !hasSelection)) {
          return const SizedBox.shrink();
        }
        return Padding(
          padding: const EdgeInsets.only(top: 8, bottom: 2),
          child: _filterChips(state, chipGroups),
        );
      },
    );
  }

  Widget _filterChips(SearchState state, List<SourceResultGroup> groups) {
    return SizedBox(
      height: 34,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        children: [
          _chip(
            label: 'All ${state.totalCount}',
            selected: state.sourceFilter == kAllSources,
            onTap: () => context.read<SearchBloc>().add(
              const SearchSourceFilterChanged(kAllSources),
            ),
          ),
          for (final g in groups)
            Padding(
              padding: const EdgeInsets.only(left: 8),
              child: _chip(
                label: '${g.sourceName} ${state.countFor(g)}',
                selected: state.sourceFilter == g.sourceId,
                onTap: () => context.read<SearchBloc>().add(
                  SearchSourceFilterChanged(g.sourceId),
                ),
              ),
            ),
        ],
      ),
    );
  }

  /// Minimal pill styling to match the redesign: quiet surface fill + hairline
  /// border at rest, a subtle accent TINT (not a solid fill) when selected.
  Widget _chip({
    required String label,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return Center(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: selected
                ? AppColors.accent.withValues(alpha: 0.14)
                : AppColors.surface,
            border: Border.all(color: AppColors.hairline),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            label,
            style: AppText.caption.copyWith(
              fontSize: 12,
              color: selected ? AppColors.accent : AppColors.textSecondary,
              fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }

  // ── Results body (grouped per source, layout-aware) ─────────────────────────
  Widget _resultsBody(
    SearchState state,
    double cellW,
    List<({String id, String name})> modeSources,
  ) {
    final groups = state.sortedVisibleGroups;

    // Sources still loading: those switched on for search that haven't
    // RESPONDED yet (not just those without a visible group — a source that
    // came back empty or errored still counts as done, via respondedSources;
    // see SearchBloc._runSearch). Without that check a source with zero
    // results kept its skeleton on screen forever, since `landed` alone can
    // never distinguish "hasn't answered" from "answered with nothing". Only
    // when viewing all sources — a selected source chip means the user has
    // narrowed to one, so other sources' skeletons would be noise.
    final landed = {for (final g in state.groups) g.sourceId};
    // Current-source-only mode queries a single source, so there are never
    // other sources still streaming in — no skeleton sections. On a specific
    // ecosystem tab, only that ecosystem's still-loading sources get skeletons
    // (the "All" tab keeps every pending source, i.e. current behaviour).
    //
    // Driven by state.queriedSources — what the bloc ACTUALLY searched — not by
    // the enabled-source list. Re-deriving it here was a guess, and it drifted:
    // a source dropped by the health check is never queried, so it never
    // responds, so its skeleton stayed on screen forever with no request in
    // flight to time out.
    final pending =
        (state.currentSourceOnly || state.sourceFilter != kAllSources)
        ? const <({String id, String name})>[]
        : modeSources
              .where(
                (s) =>
                    state.queriedSources.contains(s.id) &&
                    !landed.contains(s.id) &&
                    !state.respondedSources.contains(s.id) &&
                    (state.ecosystem == SearchEcosystem.all ||
                        ecosystemOf(s.id) == state.ecosystem),
              )
              .toList();
    final stillLoading = pending.isNotEmpty;

    // Sources that answered with a failure. Scoped exactly like `pending` —
    // a narrowed view shouldn't report on sources it isn't showing.
    final failed =
        (state.currentSourceOnly || state.sourceFilter != kAllSources)
        ? const <MapEntry<String, SourceOutcome>>[]
        : state.failedSources.entries
              .where(
                (e) =>
                    state.ecosystem == SearchEcosystem.all ||
                    ecosystemOf(e.key) == state.ecosystem,
              )
              .toList();

    if (groups.isEmpty && !stillLoading && failed.isEmpty) {
      return _noResults(state);
    }

    // A single-source view reads best as the dense flat grid rather than one
    // lonely section: either an explicit chip selection, or only one source
    // returned and nothing else is still streaming in.
    final singleSource =
        state.sourceFilter != kAllSources ||
        (groups.length == 1 && !stillLoading);
    final layout = _searchPrefs.layout;

    // A single source always reads best as the full grid — a lone horizontal
    // row is cramped — regardless of the All-view layout setting. 3 columns
    // (grouped-by-source sections below are the denser 4-up grid).
    if (singleSource) {
      return _resultsGrid(state.visibleResults, loadingMore: state.searchLoadingMore);
    }

    final sections = <Widget>[
      for (final g in groups)
        if (layout == SearchLayout.horizontal)
          _sourceRow(g, cellW)
        else
          _sourceGrid(g, cellW),
      // Sources whose results haven't arrived yet.
      if (stillLoading)
        for (final s in pending) _skeletonSection(s.name, layout),
      // Sources that broke. Shown in place, with why, rather than just going
      // missing from the list with no explanation.
      for (final f in failed) _failedSection(f.key, f.value),
    ];

    return ListView(
      padding: EdgeInsets.only(
        top: 6,
        bottom: 24 + MediaQuery.paddingOf(context).bottom,
      ),
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      children: [
        // Separator BETWEEN sections, never after the last one — a divider
        // hanging under the final section reads as a section that failed to
        // load rather than as the end of the list.
        for (var i = 0; i < sections.length; i++) ...[
          sections[i],
          if (i != sections.length - 1) _sectionGap(),
        ],
      ],
    );
  }

  /// Section header — source name (semibold) + a muted count next to it. When
  /// [onSeeAll] is provided a right-aligned muted "See all ›" link opens that
  /// source's full results (shown only when the section is capped).
  ///
  /// [onFilter] and [filterActive] are for Aniyomi (`ani:`) sources only.
  ///
  /// [pending] renders the "still searching" skeleton-header variant: the name
  /// muted and "searching…" where the count goes, instead of a real count.
  Widget _sectionHeader(
    String name,
    int count, {
    VoidCallback? onSeeAll,
    VoidCallback? onFilter,
    bool filterActive = false,
    bool pending = false,
  }) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
      // Every header the same height whether or not it has the filter /
      // "See all" controls.
      //
      // Without this a header with neither collapses to the title's own line
      // height and the section divider above it lands right on the text.
      // CloudStream sources have no filters and most sections aren't capped, so
      // theirs were the bare ones; the manga sources looked fine only because
      // their filter IconButton (minHeight 36) happened to hold the row open.
      child: ConstrainedBox(
        constraints: const BoxConstraints(minHeight: 36),
        child: Row(
          children: [
            Expanded(
              child: Row(
                children: [
                  Flexible(
                    child: Text(
                      name,
                      style: AppText.body.copyWith(
                        fontSize: 13.5,
                        fontWeight: FontWeight.w600,
                        color: pending
                            ? AppColors.textTertiary
                            : AppColors.textPrimary,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  if (pending || count > 0) ...[
                    const SizedBox(width: 8),
                    Text(
                      pending ? 'searching…' : '$count',
                      style: AppText.caption.copyWith(fontSize: 11.5),
                    ),
                  ],
                ],
              ),
            ),
            if (onFilter != null)
              IconButton(
                onPressed: onFilter,
                icon: Icon(
                  Icons.tune_rounded,
                  size: 20,
                  color: filterActive
                      ? AppColors.accent
                      : AppColors.textTertiary,
                ),
                tooltip: 'Source filters',
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
              ),
            if (onSeeAll != null)
              GestureDetector(
                onTap: onSeeAll,
                behavior: HitTestBehavior.opaque,
                child: Padding(
                  padding: const EdgeInsets.only(left: 8),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'See all',
                        style: AppText.caption.copyWith(
                          color: AppColors.textTertiary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Icon(
                        Icons.chevron_right_rounded,
                        size: 18,
                        color: AppColors.textTertiary,
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  /// Horizontal (CloudStream-style) poster row for one source. Capped to
  /// [_kSourcePreviewCap]; the header's "See all" opens the full grid.
  Widget _sourceRow(SourceResultGroup g, double cellW) {
    const itemW = 124.0;
    const itemH = 210.0;
    final overflows = g.items.length > _kSourcePreviewCap;
    final preview = overflows
        ? g.items.take(_kSourcePreviewCap).toList(growable: false)
        : g.items;
    final filter = _sourceFilterFor(
      g.sourceId,
      context.read<SearchBloc>().state,
    );
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        _sectionHeader(
          g.sourceName,
          g.items.length,
          onSeeAll: overflows ? () => _openSourceSeeAll(g) : null,
          onFilter: filter.onFilter,
          filterActive: filter.active,
        ),
        SizedBox(
          height: itemH,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            // With a screen reader on, build every poster (not just the lazy
            // window) so TalkBack can reach each one and the row auto-scrolls to
            // it — otherwise swipe navigation stalls at the first few. Sighted
            // users keep the lazy 600px window unchanged.
            // `accessibleNavigationOf`, not `MediaQuery.of(...)`: the latter
            // subscribes to every aspect including viewInsets, so each row
            // rebuilt on every frame of the keyboard sliding in or out.
            cacheExtent: MediaQuery.accessibleNavigationOf(context)
                ? double.infinity
                : 600,
            itemCount: preview.length,
            itemBuilder: (context, i) {
              final item = preview[i];
              return Padding(
                padding: const EdgeInsets.only(right: 12),
                child: SizedBox(
                  width: itemW,
                  child: RepaintBoundary(
                    child: RevealItem(
                      index: i,
                      child: PosterCard(
                        title: item.title,
                        imageUrl: item.cover,
                        headers: item.coverHeaders,
                        tags: _tagsFor(item),
                        qualityBadge: item.quality,
                        dubBadge: item.dubBadge,
                        cellWidth: itemW,
                        onTap: () => _openDetail(item),
                        onLongPress: () => _showInfo(item),
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  /// Vertical grid for one source, under its header. Capped to
  /// [_kSourcePreviewCap]; the header's "See all" opens the full grid.
  Widget _sourceGrid(SourceResultGroup g, double cellW) {
    final overflows = g.items.length > _kSourcePreviewCap;
    final preview = overflows
        ? g.items.take(_kSourcePreviewCap).toList(growable: false)
        : g.items;
    final filter = _sourceFilterFor(
      g.sourceId,
      context.read<SearchBloc>().state,
    );
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        _sectionHeader(
          g.sourceName,
          g.items.length,
          onSeeAll: overflows ? () => _openSourceSeeAll(g) : null,
          onFilter: filter.onFilter,
          filterActive: filter.active,
        ),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 16),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            childAspectRatio: 0.62,
            crossAxisSpacing: 12,
            mainAxisSpacing: 16,
          ),
          itemCount: preview.length,
          itemBuilder: (context, i) {
            final item = preview[i];
            return RevealItem(
              index: i,
              child: PosterCard(
                title: item.title,
                imageUrl: item.cover,
                headers: item.coverHeaders,
                tags: _tagsFor(item),
                qualityBadge: item.quality,
                dubBadge: item.dubBadge,
                cellWidth: cellW,
                onTap: () => _openDetail(item),
                onLongPress: () => _showInfo(item),
              ),
            );
          },
        ),
      ],
    );
  }

  /// Space between two source sections.
  ///
  /// Two sources used to run together as one continuous mixed grid: the 18px
  /// gap was barely wider than the grid's own 16px row spacing, so there was no
  /// way to see where one source ended. The rule is what separates them.
  ///
  /// No bottom padding on purpose. [_sectionHeader] already brings its own
  /// space above the title — its Row is 36 tall because of the filter
  /// IconButton's minHeight, with the title vertically centred — so padding
  /// underneath here lands on top of that and pushes the rule visibly off
  /// centre (measured 32px above vs 73px below before this).
  Widget _sectionGap() => Padding(
    padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
    child: Divider(height: 1, thickness: 1, color: AppColors.hairline),
  );

  /// A source that failed this run: its name, why it failed, and a retry that
  /// re-queries just this source.
  Widget _failedSection(String sourceId, SourceOutcome outcome) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Icon(_outcomeIcon(outcome), size: 18, color: AppColors.textTertiary),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  sl<SourceRepository>().displayName(sourceId),
                  style: AppText.body.copyWith(
                    fontSize: 13.5,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textSecondary,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Text(outcomeReason(outcome), style: AppText.caption),
              ],
            ),
          ),
          TextButton(
            onPressed: () =>
                context.read<SearchBloc>().add(SearchRetryRequested(sourceId)),
            child: Text(
              'Retry',
              style: AppText.button.copyWith(
                fontSize: 13,
                color: AppColors.accent,
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// The whole search failed — nothing came back at all. Names what went wrong
  /// per source instead of the old blanket "try again".
  Widget _errorView(SearchState state) {
    final failed = state.failedSources.entries.toList();
    final repo = sl<SourceRepository>();
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.cloud_off_rounded,
              size: 52,
              color: AppColors.textTertiary,
            ),
            const SizedBox(height: 14),
            Text(
              // state.error is set for the cases that aren't a source failure
              // at all (nothing switched on to search).
              state.error ??
                  (failed.length == 1
                      ? 'That source could not be reached'
                      : 'No source could be reached'),
              textAlign: TextAlign.center,
              style: AppText.headline,
            ),
            if (failed.isNotEmpty) ...[
              const SizedBox(height: 10),
              // Capped: with a dozen sources switched on, a full list would push
              // the retry off screen.
              for (final f in failed.take(4))
                Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: Text(
                    '${repo.displayName(f.key)} — '
                    '${outcomeReason(f.value).toLowerCase()}',
                    textAlign: TextAlign.center,
                    style: AppText.caption,
                  ),
                ),
              if (failed.length > 4)
                Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: Text(
                    'and ${failed.length - 4} more',
                    style: AppText.caption,
                  ),
                ),
              const SizedBox(height: 16),
              TextButton(
                onPressed: () => context.read<SearchBloc>().add(
                  const SearchRetryRequested(),
                ),
                child: Text(
                  'Retry',
                  style: AppText.button.copyWith(color: AppColors.accent),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  /// A loading skeleton for a source section that hasn't returned yet — name
  /// muted, "searching…" where the count goes, grid matching [_sourceGrid].
  Widget _skeletonSection(String name, SearchLayout layout) {
    if (layout == SearchLayout.horizontal) {
      return const RowSkeleton();
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        _sectionHeader(name, 0, pending: true),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: SkeletonGrid(),
        ),
      ],
    );
  }

  /// Cleaner no-results state with the searched query echoed back.
  Widget _noResults(SearchState state) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.search_off_rounded,
              size: 52,
              color: AppColors.textTertiary,
            ),
            const SizedBox(height: 14),
            Text(
              'No results for “${state.query}”',
              textAlign: TextAlign.center,
              style: AppText.headline,
            ),
            const SizedBox(height: 6),
            Text(
              state.hasActiveFilter
                  ? 'Try clearing your filters or searching a different title.'
                  : 'Check the spelling or try a different title.',
              textAlign: TextAlign.center,
              style: AppText.caption,
            ),
            if (state.hasActiveFilter) ...[
              const SizedBox(height: 16),
              TextButton(
                onPressed: () {
                  final bloc = context.read<SearchBloc>();
                  bloc
                    ..add(
                      const SearchContentFilterChanged(SearchContentFilter.all),
                    )
                    ..add(const SearchAudioFilterChanged(SearchAudioFilter.any))
                    ..add(const SearchGenreFilterChanged(null));
                },
                child: Text(
                  'Clear filters',
                  style: AppText.body.copyWith(color: AppColors.accent),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  // ── Flat results grid (single-source / vertical) ──────────────────────────
  Widget _resultsGrid(List<MediaItem> items, {bool loadingMore = false}) {
    final cellW = _searchGridCellWidth();
    return GridView.builder(
      controller: _discoverScrollController,
      padding: EdgeInsets.fromLTRB(
        16,
        6,
        16,
        24 + MediaQuery.paddingOf(context).bottom,
      ),
      cacheExtent: 800,
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: _searchGridColumns,
        childAspectRatio: 0.62,
        crossAxisSpacing: 12,
        mainAxisSpacing: 16,
      ),
      itemCount: items.length + (loadingMore ? _searchGridColumns : 0),
      itemBuilder: (context, i) {
        if (i >= items.length) {
          return const Center(child: CircularProgressIndicator(strokeWidth: 2));
        }
        final item = items[i];
        return PosterCard(
          title: item.title,
          imageUrl: item.cover,
          headers: item.coverHeaders,
          tags: _tagsFor(item),
          qualityBadge: item.quality,
          dubBadge: item.dubBadge,
          cellWidth: cellW,
          onTap: () => _openDetail(item),
          onLongPress: () => _showInfo(item),
        );
      },
    );
  }

  // ── Idle view: endless Discover feed ───────────────────────────────────────
  Widget _idleView(SearchState state) {
    final items = state.discoverItems;
    if (items.isEmpty && state.status == SearchStatus.loading) {
      return const Center(child: CircularProgressIndicator(strokeWidth: 2));
    }
    if (items.isEmpty) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.explore_outlined, size: 48, color: AppColors.textTertiary),
            SizedBox(height: 12),
            Text('Nothing to discover with these filters', style: AppText.body),
          ],
        ),
      );
    }
    final cellW = _searchGridCellWidth();
    return GridView.builder(
      controller: _discoverScrollController,
      padding: EdgeInsets.fromLTRB(
        16,
        4,
        16,
        24 + MediaQuery.paddingOf(context).bottom,
      ),
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: _searchGridColumns,
        childAspectRatio: 0.62,
        crossAxisSpacing: 12,
        mainAxisSpacing: 16,
      ),
      itemCount: items.length +
          (state.discoverLoadingMore ? _searchGridColumns : 0),
      itemBuilder: (context, i) {
        if (i >= items.length) {
          return const Center(child: CircularProgressIndicator(strokeWidth: 2));
        }
        final item = items[i];
        return PosterCard(
          title: item.title,
          imageUrl: item.cover,
          headers: item.coverHeaders,
          tags: _tagsFor(item),
          qualityBadge: item.quality,
          dubBadge: item.dubBadge,
          cellWidth: cellW,
          onTap: () => _openDetail(item),
          onLongPress: () => _showInfo(item),
        );
      },
    );
  }

  // ── Type-ahead suggestion list (history + live titles) ────────────────────
  Widget _suggestionList(List<String> suggestions) {
    final history = _history.recent().map((e) => e.toLowerCase()).toSet();
    return ListView.builder(
      padding: EdgeInsets.only(
        top: 4,
        bottom: 24 + MediaQuery.paddingOf(context).bottom,
      ),
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      itemCount: suggestions.length,
      itemBuilder: (context, i) {
        final s = suggestions[i];
        final fromHistory = history.contains(s.toLowerCase());
        return _suggestionRow(s, fromHistory: fromHistory);
      },
    );
  }

  Widget _suggestionRow(String q, {required bool fromHistory}) {
    return InkWell(
      onTap: () => _runQuery(q),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 13),
        child: Row(
          children: [
            Icon(
              fromHistory ? Icons.history_rounded : Icons.search_rounded,
              size: 18,
              color: AppColors.textTertiary,
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                q,
                style: AppText.body.copyWith(color: AppColors.textPrimary),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            // Tap to fill the field without running yet (CloudStream-style).
            GestureDetector(
              onTap: () {
                _controller.value = TextEditingValue(
                  text: q,
                  selection: TextSelection.collapsed(offset: q.length),
                );
                context.read<SearchBloc>().add(SearchQueryChanged(q));
              },
              child: const Padding(
                padding: EdgeInsets.all(4),
                child: Icon(
                  Icons.north_west_rounded,
                  size: 16,
                  color: AppColors.textTertiary,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

}

/// The filter sheet's "search in these sources" category list. Anime mode's
/// three categories (in this exact order) are the original hardcoded
/// literal, untouched; a reading mode gets its own single category (Manga or
/// Novel) instead of Anime/Movies & Series/NSFW, which are always empty for
/// it anyway. Mirrors `_SourcePickerSheetState._grouped()`'s categories in
/// source_switcher.dart. A top-level function (not inlined in
/// [_SearchFilterSheet]) so it's unit-testable without a real [SearchBloc].
List<({String title, List<({String id, String label, String? repo})> rows})>
searchFilterSections(SourceBuckets buckets, ContentMode mode) {
  final readingBucket = mode == ContentMode.manga
      ? buckets.manga
      : buckets.novel;
  return [
    if (!mode.isReading && buckets.anime.isNotEmpty)
      (title: 'Anime', rows: buckets.anime),
    if (!mode.isReading && buckets.movies.isNotEmpty)
      (title: 'Movies & Series', rows: buckets.movies),
    if (!mode.isReading && buckets.nsfw.isNotEmpty)
      (title: 'NSFW', rows: buckets.nsfw),
    if (mode.isReading && readingBucket.isNotEmpty)
      (title: mode.label, rows: readingBucket),
  ];
}

/// Whether the filter sheet's Type and Audio groups apply in [mode]. Both are
/// anime-only concepts — [SearchContentFilter] only distinguishes anime vs
/// movie (nothing manga/novel results ever are), and [SearchAudioFilter] keys
/// off [MediaItem.subCount]/[dubCount], which reading sources never set.
/// Showing either group outside anime mode used to let every option filter
/// out 100% of results. A top-level function (same pattern as
/// [searchFilterSections]) so it's unit-testable without pumping the sheet.
bool searchTypeAudioGroupsVisible(ContentMode mode) => !mode.isReading;

/// Which ecosystem's per-source filter sheet [sourceId] opens — Aniyomi for
/// `ani:` ids, Mihon for `mihon:` ids, or null for everything else (no
/// per-source filter button shown). Drives the filter icon on the
/// single-source control row and both source-section headers. A top-level function (same pattern as
/// [searchFilterSections]) so it's unit-testable without pumping the sheet.
enum SourceFilterEcosystem { aniyomi, mihon }

SourceFilterEcosystem? sourceFilterEcosystemOf(String sourceId) {
  if (sourceId.startsWith('ani:')) return SourceFilterEcosystem.aniyomi;
  if (sourceId.startsWith('mihon:')) return SourceFilterEcosystem.mihon;
  return null;
}

/// The filter sheet's "no sources" state. Anime mode's wording (a bare,
/// button-less line) is unchanged; a reading mode gets a reading-specific
/// message and an install CTA — same wording/route as the source picker's
/// install CTA and Home's [HomeLoadedEmptyView].
class SearchSourcesEmptyView extends StatelessWidget {
  const SearchSourcesEmptyView({
    super.key,
    required this.mode,
    required this.onInstallSources,
  });

  final ContentMode mode;
  final VoidCallback onInstallSources;

  @override
  Widget build(BuildContext context) {
    if (!mode.isReading) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 28),
        child: Center(child: Text('No sources installed', style: AppText.body)),
      );
    }
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 28),
      child: EmptyState(
        icon: Icons.source_outlined,
        message: 'No ${mode.label} sources yet',
        actionLabel: 'Browse repositories',
        onAction: onInstallSources,
      ),
    );
  }
}

/// The merged filter sheet: Sort · Type (anime only) · Audio (anime only) ·
/// Genre, plus a single "Search in sources" row that opens the categorised
/// source list as its own sub-sheet ([_openSourcesSheet]). Every group here
/// filters/sorts real data — see [SearchState] — and every selection applies
/// live via the bloc, so the footer's primary button always reads the
/// CURRENT result count rather than something computed after closing.
class _SearchFilterSheet extends StatelessWidget {
  const _SearchFilterSheet();

  /// Resets every group in this sheet back to its default, including
  /// [SearchSort] — sort now lives in the same sheet as the narrowing
  /// filters, so one Reset covers both.
  void _reset(BuildContext context, List<String> allIds) {
    final state = context.read<SearchBloc>().state;
    if (!state.currentSourceOnly) {
      sl<SearchSourcePrefs>().setManyIncluded(allIds, true);
    }
    context.read<SearchBloc>()
      ..add(const SearchCatalogSourceChanged('tmdb'))
      ..add(const SearchCatalogChanged(SearchCatalog.trending))
      ..add(const SearchDiscoverTypeChanged(SearchDiscoverType.all))
      ..add(const SearchSortChanged(SearchSort.bestMatch))
      ..add(const SearchContentFilterChanged(SearchContentFilter.all))
      ..add(const SearchAudioFilterChanged(SearchAudioFilter.any))
      ..add(const SearchGenreFilterChanged(null))
      ..add(const SearchStatusFilterChanged(SearchStatusFilter.any));
  }

  bool _canReset(SearchState state, SearchSourcePrefs prefs) =>
      state.hasActiveFilter ||
      state.catalogSource != SearchCatalogSource.tmdb ||
      state.catalog != SearchCatalog.trending ||
      state.sort != SearchSort.bestMatch ||
      (!state.currentSourceOnly && prefs.excluded.isNotEmpty);

  @override
  Widget build(BuildContext context) {
    // bloc/widget tests don't always register ContentModeCubit — fall back to
    // anime, which shows every group (the pre-mode-awareness behaviour).
    final mode = sl.isRegistered<ContentModeCubit>()
        ? sl<ContentModeCubit>().state
        : ContentMode.anime;
    final buckets = filterBucketsForMode(categorizedSources(), mode);
    final prefs = sl<SearchSourcePrefs>();
    final sections = searchFilterSections(buckets, mode);
    final allIds = [for (final s in sections) ...s.rows.map((r) => r.id)];
    final showTypeAudio = searchTypeAudioGroupsVisible(mode);

    return SafeArea(
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.sizeOf(context).height * 0.86,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 36,
              height: 4,
              margin: const EdgeInsets.fromLTRB(0, 12, 0, 12),
              decoration: BoxDecoration(
                color: AppColors.hairline,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            _header(context, allIds, prefs),
            Flexible(
              child: ListenableBuilder(
                listenable: prefs,
                builder: (context, _) => ListView(
                  padding: const EdgeInsets.only(bottom: 8),
                  children: [
                    _catalogSourceSelector(context),
                    _catalogSelector(context),
                    _sortSelector(context),
                    _discoverTypeSelector(context),
                    // Audio needs anime mode and results that actually report
                    // sub/dub counts.
                    if (showTypeAudio &&
                        context.watch<SearchBloc>().state.hasAnyAudio)
                      _audioSelector(context),
                    _genreSelector(context),
                    _statusSelector(context),
                    if (!context.read<SearchBloc>().state.currentSourceOnly)
                      _sourcesSummaryRow(context, sections, prefs, mode),
                  ],
                ),
              ),
            ),
            _footer(context, allIds, prefs),
          ],
        ),
      ),
    );
  }

  /// "Filters" + a live count badge + Reset (hidden while there's nothing to
  /// reset).
  Widget _header(
    BuildContext context,
    List<String> allIds,
    SearchSourcePrefs prefs,
  ) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
      child: Row(
        children: [
          Text('Filters', style: AppText.headline),
          const SizedBox(width: 8),
          BlocBuilder<SearchBloc, SearchState>(
            buildWhen: (p, c) =>
                p.sort != c.sort ||
                p.catalogSource != c.catalogSource ||
                p.catalog != c.catalog ||
                p.discoverType != c.discoverType ||
                p.contentFilter != c.contentFilter ||
                p.audioFilter != c.audioFilter ||
                p.genreFilter != c.genreFilter ||
                p.statusFilter != c.statusFilter,
            builder: (context, state) {
              final count = state.activeFilterCount;
              if (count == 0) return const SizedBox.shrink();
              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                decoration: BoxDecoration(
                  color: AppColors.accent,
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  '$count',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 10.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              );
            },
          ),
          const Spacer(),
          BlocBuilder<SearchBloc, SearchState>(
            buildWhen: (p, c) =>
                p.contentFilter != c.contentFilter ||
                p.audioFilter != c.audioFilter ||
                p.genreFilter != c.genreFilter ||
                p.statusFilter != c.statusFilter ||
                p.sort != c.sort ||
                p.currentSourceOnly != c.currentSourceOnly,
            builder: (context, state) {
              if (!_canReset(state, prefs)) return const SizedBox.shrink();
              return TextButton(
                onPressed: () => _reset(context, allIds),
                child: Text(
                  'Reset',
                  style: AppText.body.copyWith(color: AppColors.accent),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  /// Reset (ghost, hidden while there's nothing to reset) + the primary
  /// action, which states the outcome ("Show N results") rather than just
  /// "Done" — N is [SearchState.totalCount], the SAME live, already-fetched
  /// count the "N results"/pill labels use elsewhere on this screen, so it
  /// updates the instant a pill is tapped without any re-search.
  Widget _footer(
    BuildContext context,
    List<String> allIds,
    SearchSourcePrefs prefs,
  ) {
    return BlocBuilder<SearchBloc, SearchState>(
      buildWhen: (p, c) =>
          p.contentFilter != c.contentFilter ||
          p.audioFilter != c.audioFilter ||
          p.genreFilter != c.genreFilter ||
          p.statusFilter != c.statusFilter ||
          p.sort != c.sort ||
          p.catalogSource != c.catalogSource ||
          p.catalog != c.catalog ||
          p.discoverType != c.discoverType ||
          p.groups != c.groups ||
          p.ecosystem != c.ecosystem ||
          p.currentSourceOnly != c.currentSourceOnly,
      builder: (context, state) {
        final canReset = _canReset(state, prefs);
        final n = state.totalCount;
        return SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 10, 20, 12),
            child: Row(
              children: [
                if (canReset) ...[
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => _reset(context, allIds),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: AppColors.hairline),
                        foregroundColor: AppColors.textSecondary,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text('Reset'),
                    ),
                  ),
                  const SizedBox(width: 10),
                ],
                Expanded(
                  child: FilledButton(
                    onPressed: () => Navigator.pop(context),
                    style: FilledButton.styleFrom(
                      backgroundColor: AppColors.accent,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: Text(
                      state.query.trim().isEmpty
                          ? 'Apply'
                          : 'Show $n result${n == 1 ? '' : 's'}',
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  /// A small uppercase section label used above each filter group.
  Widget _filterLabel(String text) {
    return Text(
      text,
      style: AppText.caption.copyWith(
        color: AppColors.textTertiary,
        fontWeight: FontWeight.w700,
        letterSpacing: 0.5,
      ),
    );
  }

  /// A selectable pill (chip) used across the filter selectors. Unselected:
  /// quiet surface fill. Selected: a soft accent TINT (not a solid fill) with
  /// a matching subtle accent border, so the active pill reads as "on" without
  /// shouting.
  Widget _pill({
    required String label,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
        decoration: BoxDecoration(
          color: selected ? AppColors.accentSoft : AppColors.surface2,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: selected
                ? AppColors.accent.withValues(alpha: 0.4)
                : Colors.transparent,
          ),
        ),
        child: Text(
          label,
          style: AppText.caption.copyWith(
            color: selected ? AppColors.accent : AppColors.textSecondary,
            fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
          ),
        ),
      ),
    );
  }

  Widget _catalogSourceSelector(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _filterLabel('CATALOG SOURCE'),
          const SizedBox(height: 10),
          BlocBuilder<SearchBloc, SearchState>(
            buildWhen: (p, c) => p.catalogSource != c.catalogSource,
            builder: (context, state) => Wrap(
              spacing: 8,
              children: [
                _pill(label: 'TMDB', selected: state.catalogSource == SearchCatalogSource.tmdb,
                  onTap: () => context.read<SearchBloc>().add(const SearchCatalogSourceChanged('tmdb'))),
                _pill(label: 'ThePornDB', selected: state.catalogSource == SearchCatalogSource.thePornDb,
                  onTap: () => context.read<SearchBloc>().add(const SearchCatalogSourceChanged('theporndb'))),
                _pill(label: 'Mixed', selected: state.catalogSource == SearchCatalogSource.mixed,
                  onTap: () => context.read<SearchBloc>().add(const SearchCatalogSourceChanged('mixed'))),
                _pill(label: 'Providers', selected: state.catalogSource == SearchCatalogSource.providers,
                  onTap: () => context.read<SearchBloc>().add(const SearchCatalogSourceChanged('providers'))),
              ],
            ),
          ),
          const SizedBox(height: 6),
        ],
      ),
    );
  }

  Widget _catalogSelector(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _filterLabel('CATALOG'),
          const SizedBox(height: 10),
          BlocBuilder<SearchBloc, SearchState>(
            buildWhen: (p, c) => p.catalog != c.catalog,
            builder: (context, state) => Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final c in SearchCatalog.values)
                  _pill(label: c.label, selected: state.catalog == c,
                    onTap: () => context.read<SearchBloc>().add(SearchCatalogChanged(c))),
              ],
            ),
          ),
          const SizedBox(height: 6),
        ],
      ),
    );
  }

  /// Sort selector, merged in from the old standalone sort sheet. Applies
  /// immediately, same as every other pill here.
  Widget _sortSelector(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _filterLabel('SORT'),
          const SizedBox(height: 10),
          BlocBuilder<SearchBloc, SearchState>(
            buildWhen: (p, c) => p.sort != c.sort,
            builder: (context, state) => Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final s in SearchSort.values)
                  _pill(
                    label: s.label,
                    selected: state.sort == s,
                    onTap: () =>
                        context.read<SearchBloc>().add(SearchSortChanged(s)),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 6),
        ],
      ),
    );
  }

  Widget _discoverTypeSelector(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _filterLabel('TYPE'),
          const SizedBox(height: 10),
          BlocBuilder<SearchBloc, SearchState>(
            buildWhen: (p, c) => p.discoverType != c.discoverType,
            builder: (context, state) => Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final type in SearchDiscoverType.values)
                  _pill(
                    label: type.label,
                    selected: state.discoverType == type,
                    onTap: () => context.read<SearchBloc>().add(
                      SearchDiscoverTypeChanged(type),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 6),
        ],
      ),
    );
  }

  /// The content-type segmented selector, wired to the bloc so the results
  /// filter updates the moment a chip is tapped. Anime mode only — see
  /// [searchTypeAudioGroupsVisible].

  /// Audio (Subbed/Dubbed) selector — real data, see
  /// [MediaItem.subCount]/[dubCount]. Anime mode only.
  Widget _audioSelector(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _filterLabel('AUDIO'),
          const SizedBox(height: 10),
          BlocBuilder<SearchBloc, SearchState>(
            buildWhen: (p, c) => p.audioFilter != c.audioFilter,
            builder: (context, state) => Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final f in SearchAudioFilter.values)
                  _pill(
                    label: f.label,
                    selected: state.audioFilter == f,
                    onTap: () => context.read<SearchBloc>().add(
                      SearchAudioFilterChanged(f),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 6),
        ],
      ),
    );
  }

  /// Genre selector, pills derived from the actual result set
  /// ([SearchState.availableGenres]) rather than a fixed list — a genre only
  /// appears here if some result can actually match it. "Any" clears it.
  /// Hidden entirely when there's nothing to offer AND no filter is active;
  /// kept visible (with just "Any") while a filter is active so a stale
  /// selection is always reachable to clear.
  Widget _genreSelector(BuildContext context) {
    return BlocBuilder<SearchBloc, SearchState>(
      buildWhen: (p, c) =>
          p.genreFilter != c.genreFilter || p.groups != c.groups,
      builder: (context, state) {
        final available = state.catalogSource == SearchCatalogSource.tmdb
            ? const ['Action', 'Adventure', 'Animation', 'Comedy', 'Crime', 'Documentary', 'Drama', 'Family', 'Fantasy', 'Horror', 'Mystery', 'Romance', 'Science Fiction', 'Thriller', 'History', 'Music']
            : state.availableGenres;
        if (available.isEmpty && state.genreFilter == null) {
          return const SizedBox.shrink();
        }
        final selectedLower = state.genreFilter?.trim().toLowerCase();
        return Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 4),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  _filterLabel('GENRE'),
                  const SizedBox(width: 6),
                  Text(
                    state.catalogSource == SearchCatalogSource.tmdb ? '' : '· from your results',
                    style: AppText.caption.copyWith(
                      color: AppColors.textTertiary,
                      fontWeight: FontWeight.w400,
                      letterSpacing: 0,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  _pill(
                    label: 'Any',
                    selected: state.genreFilter == null,
                    onTap: () => context.read<SearchBloc>().add(
                      const SearchGenreFilterChanged(null),
                    ),
                  ),
                  for (final g in available)
                    _pill(
                      label: g,
                      selected: g.toLowerCase() == selectedLower,
                      onTap: () {
                        final next = g.toLowerCase() == selectedLower
                            ? null
                            : g;
                        context.read<SearchBloc>().add(
                          SearchGenreFilterChanged(next),
                        );
                      },
                    ),
                ],
              ),
              if (state.genreFilter != null && state.hasItemsWithoutGenre) ...[
                const SizedBox(height: 6),
                Text(
                  "some sources don't provide genres",
                  style: AppText.caption.copyWith(
                    color: AppColors.textTertiary,
                  ),
                ),
              ],
              const SizedBox(height: 6),
            ],
          ),
        );
      },
    );
  }

  /// Status (Ongoing/Completed) selector — real data, see [MediaItem.status]
  /// (carried from Mihon/Aniyomi, same as [MediaDetail.status]). Not mode-
  /// gated like Type/Audio — both manga (Mihon) and anime (Aniyomi) sources
  /// report it — instead it self-hides via [SearchState.hasAnyStatus], same
  /// spirit as the genre selector self-hiding when there's nothing to offer;
  /// kept visible while a filter is active so a stale selection stays
  /// reachable to clear.
  Widget _statusSelector(BuildContext context) {
    return BlocBuilder<SearchBloc, SearchState>(
      buildWhen: (p, c) =>
          p.statusFilter != c.statusFilter || p.groups != c.groups,
      builder: (context, state) {
        if (!state.hasAnyStatus &&
            state.statusFilter == SearchStatusFilter.any) {
          return const SizedBox.shrink();
        }
        return Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 4),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _filterLabel('STATUS'),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final f in SearchStatusFilter.values)
                    _pill(
                      label: f.label,
                      selected: state.statusFilter == f,
                      onTap: () => context.read<SearchBloc>().add(
                        SearchStatusFilterChanged(f),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 6),
            ],
          ),
        );
      },
    );
  }

  /// A single tappable row summarising the "search in these sources" list —
  /// "Search in sources · N of M ›" — that opens the exact same categorised
  /// switches as a sub-sheet ([_openSourcesSheet]), so the main sheet stays
  /// short instead of listing every source inline.
  Widget _sourcesSummaryRow(
    BuildContext context,
    List<({String title, List<({String id, String label, String? repo})> rows})>
    sections,
    SearchSourcePrefs prefs,
    ContentMode mode,
  ) {
    final allIds = [for (final s in sections) ...s.rows.map((r) => r.id)];
    final onCount = allIds.where(prefs.isIncluded).length;
    return InkWell(
      onTap: () => _openSourcesSheet(context, sections, prefs, mode),
      child: Container(
        margin: const EdgeInsets.fromLTRB(20, 18, 20, 0),
        padding: const EdgeInsets.symmetric(vertical: 13),
        decoration: const BoxDecoration(
          border: Border(top: BorderSide(color: AppColors.hairline)),
        ),
        child: Row(
          children: [
            Text(
              'Search in sources',
              style: AppText.body.copyWith(
                fontSize: 13.5,
                color: AppColors.textPrimary,
              ),
            ),
            const Spacer(),
            Text(
              '$onCount of ${allIds.length}',
              style: AppText.caption.copyWith(color: AppColors.textTertiary),
            ),
            const SizedBox(width: 4),
            Icon(
              Icons.chevron_right_rounded,
              size: 18,
              color: AppColors.textTertiary,
            ),
          ],
        ),
      ),
    );
  }

  /// The "search in these sources" sub-sheet — same categorised
  /// switches/"turn all on/off" behaviour as before, just moved off the main
  /// sheet. [filterSheetContext] is the MAIN sheet's context, kept so the
  /// empty-state's install CTA can close both sheets and push
  /// [ZangetsuSourcesScreen], same as it always has.
  void _openSourcesSheet(
    BuildContext filterSheetContext,
    List<({String title, List<({String id, String label, String? repo})> rows})>
    sections,
    SearchSourcePrefs prefs,
    ContentMode mode,
  ) {
    showModalBottomSheet<void>(
      context: filterSheetContext,
      backgroundColor: AppColors.surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (subCtx) => ListenableBuilder(
        listenable: prefs,
        builder: (subCtx, _) => SafeArea(
          child: ConstrainedBox(
            constraints: BoxConstraints(
              maxHeight: MediaQuery.of(subCtx).size.height * 0.8,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 36,
                  height: 4,
                  margin: const EdgeInsets.fromLTRB(0, 12, 0, 12),
                  decoration: BoxDecoration(
                    color: AppColors.hairline,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text('Search in sources', style: AppText.headline),
                  ),
                ),
                Flexible(
                  child: sections.isEmpty
                      ? SearchSourcesEmptyView(
                          mode: mode,
                          onInstallSources: () {
                            Navigator.of(subCtx).pop();
                            Navigator.of(filterSheetContext).pop();
                            Navigator.of(filterSheetContext).push(
                              MaterialPageRoute<void>(
                                builder: (_) => const ZangetsuSourcesScreen(
                                  openToRepos: true,
                                ),
                              ),
                            );
                          },
                        )
                      : ListView(
                          padding: const EdgeInsets.only(bottom: 8),
                          children: [
                            for (final sec in sections) ...[
                              _categoryHeader(prefs, sec.title, sec.rows),
                              for (final r in sec.rows) _sourceRow(prefs, r),
                            ],
                          ],
                        ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
                  child: SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: () => Navigator.pop(subCtx),
                      style: FilledButton.styleFrom(
                        backgroundColor: AppColors.accent,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text('Done'),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _categoryHeader(
    SearchSourcePrefs prefs,
    String title,
    List<({String id, String label, String? repo})> rows,
  ) {
    final ids = rows.map((r) => r.id).toList();
    final onCount = ids.where(prefs.isIncluded).length;
    final allOn = onCount == ids.length;
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 14, 12, 6),
      child: Row(
        children: [
          Expanded(
            child: Text(
              '${title.toUpperCase()}  ·  $onCount/${ids.length}',
              style: AppText.caption.copyWith(
                color: AppColors.textTertiary,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.5,
              ),
            ),
          ),
          TextButton(
            onPressed: () => prefs.setManyIncluded(ids, !allOn),
            style: TextButton.styleFrom(
              minimumSize: const Size(0, 32),
              padding: const EdgeInsets.symmetric(horizontal: 8),
            ),
            child: Text(
              allOn ? 'Turn all off' : 'Turn all on',
              style: AppText.caption.copyWith(color: AppColors.accent),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sourceRow(
    SearchSourcePrefs prefs,
    ({String id, String label, String? repo}) r,
  ) {
    final on = prefs.isIncluded(r.id);
    return InkWell(
      onTap: () => prefs.setIncluded(r.id, !on),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 6, 12, 6),
        child: Row(
          children: [
            Expanded(
              child: Text(
                r.label,
                style: AppText.body.copyWith(
                  color: on ? AppColors.textPrimary : AppColors.textSecondary,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            Switch.adaptive(
              value: on,
              activeThumbColor: AppColors.accent,
              onChanged: (v) => prefs.setIncluded(r.id, v),
            ),
          ],
        ),
      ),
    );
  }
}
