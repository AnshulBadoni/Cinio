// swift-tools-version: 5.9
// The swift-tools-version declares the minimum version of Swift required to build this package.
//
//  Generated file. Do not edit.
//

import PackageDescription

let package = Package(
    name: "FlutterFramework",
    platforms: [
        .iOS("13.0")
    ],
    products: [
        .library(name: "FlutterFramework", targets: ["FlutterFramework"])
    ],
    dependencies: [
        
    ],
    targets: [
        .target(
            name: "FlutterFramework"
        )
    ]
)
